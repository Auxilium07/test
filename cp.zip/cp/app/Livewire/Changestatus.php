<?php

namespace App\Livewire;

use App\Models\Order;
use Illuminate\Support\Facades\Log;
use Livewire\Component;

class Changestatus extends Component
{
    public $orderStatusArray = [
        '0' => 'Не оброблений',
        '1' => 'Оброблений',
        '2' => 'Обробляєтся',
        '3' => 'Брошений',
        '4' => 'На паузі',
    ];
    public $current_status;
    #[Validate('required')] 
    public $order_id;
    #[Validate('required')] 
    public $status;
    
    public function mount($order_id, $current_status)
    {
        $this->order_id=$order_id;
        $this->current_status= $current_status;;
    }
    public function save()
    {
        $this->validate([ 
            'order_id' => 'required|integer',
            'status' => 'required|integer',
        ]); 
        $data=$this->only(['order_id', 'status']);
     
        if(is_int($data['order_id']))
        {
            Order::where("id",$data['order_id'])->update(
                ['status'=>$data['status']]
            );
         
        }
    }
  
    public function render()
    {
        return view('livewire.changestatus');
    }
}
