<?php

namespace App\Livewire;

use App\Models\Link;
use App\Models\Review;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Route;
use Livewire\Component;

class Sidemenu extends Component
{
    public $admin_side_menu=[];
    public $routes_name=[];

    public function mount($title = null)
    { 
        $this->admin_side_menu = Link::all();
        if (request()->is('admin') || request()->is('admin/*')) {
            $routes_name = [];
               
                foreach ($this->admin_side_menu as $route) {
                        $routes_name[] = $route['to'];
                    
                }

              $this->routes_name=$routes_name;
        }

        
        
        
    }
    public function render()
    {
        return view('livewire.sidemenu');
    }
}
