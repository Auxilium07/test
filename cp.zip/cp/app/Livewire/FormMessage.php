<?php

namespace App\Livewire;

use App\Models\Message;
use Livewire\Component;

class FormMessage extends Component
{
    public $user_id=null;
    #[Validate('required')] 
    public $content=null;
    public $order_id;
    public function mount($order_id=null,$user_id=null)
    {
        $this->order_id=$order_id;
        $this->user_id=$user_id;
    }

    public function save()
    {
        $this->validate([ 
            'user_id' => 'required|integer',
            'content' => 'required|min:3',
        ]); 
        if(is_int($this->order_id))
        {
            $data=$this->only(['user_id', 'content']);
            $data['message']=$data['content'];
            $data['order_id']=$this->order_id;
            unset($data['content']);
            Message::create(
                $data
            );
            $this->content=null;
            $this->dispatch('message-added',$this->order_id); 
        }
        
 
        session()->flash('status', 'Повідомлення відправлено');
    }
    public function render()
    {
        return view('livewire.form-message');
    }
}
