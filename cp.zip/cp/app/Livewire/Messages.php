<?php

namespace App\Livewire;

use App\Models\Message;
use Livewire\Component;
use Livewire\Attributes\On; 
class Messages extends Component
{
    public $messages=[];
    public $order_id;
    #[Validate('required')] 
    public $message_id;
    public function mount($order_id=null){
        if($order_id!=null)
        {
            $this->order_id=$order_id;
            $this->messages=Message::with("user")->where("order_id",$order_id)->get();
        }
    }
    #[On('message-added')] 
    public function updateMessage($order_id)
    {
        $this->reset('messages'); 
        $this->messages=Message::with("user")->where("order_id",$order_id)->orderBy('id','desc')->get();
    }
    public function delete($message_id=null,$order_id=null)
    {
        if($message_id!=null&&$order_id!=null)
      {
        Message::where("id",$message_id)->delete();
        $this->reset('messages'); 
        $this->messages=Message::with("user")->where("order_id",$order_id)->orderBy('id','desc')->get();
      }
 
    }
    public function render()
    {
        return view('livewire.messages');
    }
}
