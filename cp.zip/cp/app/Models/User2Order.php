<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Notifications\Notifiable;

class User2Order extends Model
{
    use HasFactory,Notifiable;
    protected $guarded = [];
    protected $table="user_2_order";

    public function user()
    {
        return User::where("id",$this->user_id)->first();
    }
    public function order()
    {
        return Order::where("id",$this->order_id)->first();
    }


    
}
