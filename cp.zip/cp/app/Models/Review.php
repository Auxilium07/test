<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Review extends Model
{
    use HasFactory;

    protected $guarded = [];
    public $timestamps = false;

    protected $table='reviews';
    public function getFullNameAttribute(): string
    {
        return ucfirst($this->first_name) . ' ' . ucfirst($this->midddle_name).' '. ucfirst($this->last_name);
    }

    public function getDateTextAttribute(): string
    {
        $date=$this->date;
        $date=explode("-",$date);
        $date=array_reverse($date);
        $date=implode("/",$date);
        return $date;
    }

  

}
