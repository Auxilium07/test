<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Notifications\Notifiable;

class Order extends Model
{

    use HasFactory,Notifiable;
    protected $table = "order";
    protected $guarded = [];

    public function messages()
    {
        return $this->hasMany(Message::class);
    }
    public function users()
    {
        return $this->hasMany(User2Order::class, 'order_id');
    }
    public function lastuser()
    {
        return $this->hasMany(User2Order::class, 'order_id')->latest('id')->first();
    }
    public function fullname()
    {
        return $this->lastname.' '.$this->firstname.' '.$this->middlename;
    }
    public function statusText()
    {
        switch ($this->status) {
            case 1:
                return "Оброблений";
            case 2:
                return 'Обробляєтся';
            case 3:
                return 'Брошений';
            case 4:
                return 'На паузі';
            default:
                return 'Не оброблений';
        }
    }
}
