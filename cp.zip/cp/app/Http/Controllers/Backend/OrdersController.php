<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use App\Http\Requests\StoreOrderRequest;
use App\Models\Order;
use App\Models\User;
use App\Models\User2Order;
use App\Notifications\Backend\User\OrderCreatedNotification;
use App\Notifications\Frontend\User\OrderStatusNotification;
use Illuminate\Contracts\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;

class OrdersController extends Controller
{
    public $orderStatusArray = [
        '0' => 'Не оброблений',
        '1' => 'Оброблений',
        '2' => 'Обробляєтся',
        '3' => 'Брошений',
        '4' => 'На паузі',
    ];
    public function index(): View
    {
        $this->authorize('access_order');

        $orders = Order::when(\request()->keyword != null, function ($query) {
                $query->search(\request()->keyword);
            })
            ->when(\request()->status != null, function ($query) {
                $query->whereOrderStatus(\request()->status);
            })
            ->orderBy(\request()->sortBy ?? 'id', \request()->orderBy ?? 'desc')
            ->paginate(\request()->limitBy ?? 10);

        return view('backend.orders.index', compact('orders'));
    }

    public function show(Order $order): View
    {
        $this->authorize('show_order');

        $orderStatusArray=$this->orderStatusArray;


        return view('backend.orders.show',compact('order','orderStatusArray'));
    }

    public function update(StoreOrderRequest $request, Order $order): RedirectResponse
    {
        


        $this->authorize('edit_order');
   
        $order->update($request->except(["user_id",'_method','_token']));
        
        if($request->only("user_id")!=null&&$request->only("user_id")["user_id"]!=null)
        {
            $user_id=$request->only("user_id")["user_id"];
            $last=User2Order::where("order_id",$order->id)->orderBy("id","desc")->first("user_id");
            $count=User2Order::where("order_id",$order->id)->count();
            if($count>0&&$last!=null&&$last->user_id!=$user_id)
            {
                User2Order::where("order_id",$order->id)->update(["status"=>1]);
            }

            if($last!=null&&$last->user_id!=$user_id)
            {
                User2Order::create(["user_id"=>$user_id,"order_id"=>$order->id,"status"=>1]);
                $order->notify(new OrderStatusNotification($order));
            }
            elseif($last==null){
                User2Order::create(["user_id"=>$user_id,"order_id"=>$order->id,"status"=>1]);
                $order->notify(new OrderStatusNotification($order));
            }

        }
 
                return back()->with([
                    'message' => 'Оновлено успішно',
                    'alert-type' => 'success',
                ]);


        
    }


    public function destroy(Order $order): RedirectResponse
    {
        $this->authorize('delete_order');

        $order->delete();

        return redirect()->route('admin.orders.index')->with([
            'message' => 'Видалено успішно',
            'alert-type' => 'success'
        ]);
    }
    public function edit(Request $request, Order $order): View
    {
        $this->authorize('edit_order');
        $orderStatusArray=$this->orderStatusArray;
        $users=User::role(["user","supervisor"])->get();
        return view('backend.orders.update_order', compact('order','orderStatusArray','users'));
    }

    public function create(): View
    {
        $this->authorize('create_order');
        $users=User::role(["user",'supervisor'])->get();
        $orderStatusArray=$this->orderStatusArray;
        return view('backend.orders.create',compact('orderStatusArray','users'));
    }
    public function store(StoreOrderRequest $request): RedirectResponse
    {
        $this->authorize('create_order');
        $order=Order::create($request->except(["user_id",'_method','_token']));
     
        if($request->only("user_id")!=null&&$request->only("user_id")["user_id"]!=null)
        {
            $user_id=$request->only("user_id")["user_id"];
            User2Order::create(["user_id"=>$user_id,"order_id"=>$order->id,"status"=>1]);
            $order->notify(new OrderCreatedNotification($order));

        }
        return redirect()->route('admin.orders.index')->with([
            'message' => 'Успішно стрворено',
            'alert-type' => 'success'
        ]);
        
    }
  

}
