<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;

use App\Http\Requests\ReviewRequest;
use App\Models\Review;
use Illuminate\Contracts\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;

class ReviewController extends Controller
{
    public function index(): View
    {
        $this->authorize('access_review');

        $reviews = Review::when(\request()->keyword != null, function ($query) {
                $query->search(\request()->keyword);
            })
            ->when(\request()->status != null, function ($query) {
                $query->whereStatus(\request()->status);
            })
            ->orderBy(\request()->sortBy ?? 'id', \request()->orderBy ?? 'desc')
            ->paginate(\request()->limitBy ?? 10);
        return view('backend.reviews.index', compact('reviews'));
    }

    public function show(Review $review): View
    {
        $this->authorize('show_review');

        return view('backend.reviews.show', compact('review'));
    }

    public function edit(Review $review): View
    {
        $this->authorize('edit_review');

        return view('backend.reviews.edit', compact('review'));
    }
    public function create(): View
    {
        $this->authorize('create_review');
 
        return view('backend.reviews.create');
    }
    public function changeStatus(Request $request)
    {
        $this->authorize('edit_review');
        Review::where("id",$request->id)->update(["status"=>$request->status]);
        return redirect()->back()->with([
            'message' => 'Відгук успішно оновлена',
            'alert-type' => 'success'
        ]);
    } 
    public function update(ReviewRequest $request, Review $review): RedirectResponse
    {
        $this->authorize('edit_review');
        $data=$request->validated();
        if(preg_match('/^(?:(?:31(\/|-|\.)(?:0?[13578]|1[02]))\1|(?:(?:29|30)(\/|-|\.)(?:0?[13-9]|1[0-2])\2))(?:(?:1[6-9]|[2-9]\d)?\d{2})$|^(?:29(\/|-|\.)0?2\3(?:(?:(?:1[6-9]|[2-9]\d)?(?:0[48]|[2468][048]|[13579][26])|(?:(?:16|[2468][048]|[3579][26])00))))$|^(?:0?[1-9]|1\d|2[0-8])(\/|-|\.)(?:(?:0?[1-9])|(?:1[0-2]))\4(?:(?:1[6-9]|[2-9]\d)?\d{2})$/m',$data['date']))
        {
            $data['date']=explode("/",$data['date']);
            $data['date']=array_reverse($data['date']);
            $data['date']=implode("-",$data['date']);
        }
        $review->update($data);
        
        return redirect()->route('admin.reviews.index')->with([
            'message' => 'Успішно оновлено',
            'alert-type' => 'success'
        ]);
    }
    public function store(ReviewRequest $request)
    {
        $this->authorize('create_review');
        $data=$request->validated();
        if(preg_match('/^(?:(?:31(\/|-|\.)(?:0?[13578]|1[02]))\1|(?:(?:29|30)(\/|-|\.)(?:0?[13-9]|1[0-2])\2))(?:(?:1[6-9]|[2-9]\d)?\d{2})$|^(?:29(\/|-|\.)0?2\3(?:(?:(?:1[6-9]|[2-9]\d)?(?:0[48]|[2468][048]|[13579][26])|(?:(?:16|[2468][048]|[3579][26])00))))$|^(?:0?[1-9]|1\d|2[0-8])(\/|-|\.)(?:(?:0?[1-9])|(?:1[0-2]))\4(?:(?:1[6-9]|[2-9]\d)?\d{2})$/m',$data['date']))
        {
            $data['date']=explode("/",$data['date']);
            $data['date']=array_reverse($data['date']);
            $data['date']=implode("-",$data['date']);
        }
   
        Review::create( $data);
        
        return redirect()->route('admin.reviews.index')->with([
            'message' => 'Створено успішно',
            'alert-type' => 'success'
        ]);

    }
    public function destroy(Review $review): RedirectResponse
    {
        $this->authorize('delete_review');

        $review->delete();

        return redirect()->route('admin.reviews.index')->with([
            'message' => 'Видалено успішно',
            'alert-type' => 'success'
        ]);
    }
}
