<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use App\Services\ImageService;
use App\Traits\ImageUploadTrait;
use Illuminate\Http\Request;
use Illuminate\Contracts\View\View;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Auth;

class AdminAuthController extends Controller
{
    use ImageUploadTrait,AuthenticatesUsers;

    public function loginPage(): View
    {
        
        return view('backend.login');
    }
    public function login()
    {
        $credentials = request()->only('username', 'password');
        
        if(count($credentials)==2&&array_key_exists("username",$credentials)&&array_key_exists("password",$credentials))
        {   

        if (Auth::attempt($credentials)) {
            request()->session()->regenerate();
            return redirect()->intended('admin');
        }}
        if (auth()->check()&&auth()->user()->isAdminOrSupervisor()) {
            return redirect('/admin');
        }
    }
    public function forgotPassword(): View
    {
        return view('backend.forgot-password');
    }

    public function accountSetting(): View
    {
        return view('backend.account_setting');
    }

    public function updateAccount(Request $request): RedirectResponse
    {
        if ($request->hasFile('user_image')) {
            if (auth()->user()->user_image) {
                (new ImageService())->unlinkImage(auth()->user()->user_image, 'users');
            }
            $adminImage = (new ImageService())->storeUserImages(auth()->user()->username, $request->user_image);
        }

        if ($request->password){
            $password = bcrypt($request->password);
        }

        auth()->user()->update([
            'first_name' => $request->first_name,
            'last_name' => $request->last_name,
            'username' => $request->username,
            'email' => $request->email,
            'phone' => $request->phone,
            'status' => $request->status,
            'user_image' => $adminImage ?? auth()->user()->user_image,
            'password' => $password ?? auth()->user()->password
        ]);

        return redirect()->route('admin.index')->with([
            'message' => 'Успішно оновлено',
            'alert-type' => 'success'
        ]);
    }
}
