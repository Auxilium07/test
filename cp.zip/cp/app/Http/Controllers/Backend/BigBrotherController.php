<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use App\Models\LogModel;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\View\View;

class BigBrotherController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(): View
    {
        $this->authorize('access_logs');
        $logs = [];
        if(request()->filterBy==0){
            $logs =LogModel::query()
            ->when(\request()->keyword != null, function ($query) {
                $query->search(\request()->keyword);
            })
            ->when(\request()->start_date != null||\request()->expire_date!= null, function ($query) {
                if(\request()->start_date != null&&\request()->expire_date== null)
                    {
                        $query->whereBetween(DB::raw('DATE(created_at)'),[request()->start_date, Carbon::now()]);
                        dump(request()->expire_date);
                    }
                    elseif(\request()->start_date == null&&\request()->expire_date!= null)
                    {
                        $query->whereBetween(DB::raw('DATE(created_at)'),[ Carbon::now(),request()->expire_date]);
                    }
                    elseif(\request()->start_date != null&&\request()->expire_date!= null)
                    {
                        $query->whereBetween(DB::raw('DATE(created_at)'),[ \request()->start_date,\request()->expire_date]);
                    }
            })->when(\request()->user_id != null, function ($query) {
                $query->where("user_id",request()->user_id);
            })
            ->orderBy(\request()->sortBy ?? 'id', \request()->orderBy ?? 'desc')
            ->paginate(\request()->limitBy ?? 10);
        }
        else
        {   
            switch(request()->filterBy)
            {
                case 1:
                    $logs =LogModel::query()->lastYear()->orderBy(\request()->sortBy ?? 'id', \request()->orderBy ?? 'desc')
                    ->paginate(\request()->limitBy ?? 10);
                    break;
                case 2:
                    $logs =LogModel::query()->lastQuarter()->orderBy(\request()->sortBy ?? 'id', \request()->orderBy ?? 'desc')
                    ->paginate(\request()->limitBy ?? 10);
                    break;
                case 3:
                    $logs =LogModel::query()->last30Days()->orderBy(\request()->sortBy ?? 'id', \request()->orderBy ?? 'desc')
                    ->paginate(\request()->limitBy ?? 10);
                    break;
                case 4:
                    $logs =LogModel::query()->last7Days()->orderBy(\request()->sortBy ?? 'id', \request()->orderBy ?? 'desc')
                    ->paginate(\request()->limitBy ?? 10);
                    break;
                case 5:
                    $logs =LogModel::query()->yesterday()->orderBy(\request()->sortBy ?? 'id', \request()->orderBy ?? 'desc')
                    ->paginate(\request()->limitBy ?? 10);
                    break;
                case 6:
                        $logs =LogModel::query()->today()->orderBy(\request()->sortBy ?? 'id', \request()->orderBy ?? 'desc')
                        ->paginate(\request()->limitBy ?? 10);
                        break;
            }
        }
        
        $users=User::get();
        return view('backend.logs.index', compact(['logs',"users"]));
    }
    /**
     * Display the specified resource.
     *
     * @param  \App\Models\LogModel  $logModel
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $this->authorize('access_logs');
        $logModel=LogModel::where("id",$id)->first();
        return view('backend.logs.show', compact('logModel'));
    }

}
