<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use App\Http\Requests\StoreOrderRequest;
use App\Models\Order;
use App\Notifications\Backend\User\OrderCreatedNotification;
use Exception;
class OrdersController extends Controller
{
    

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreOrderRequest $request)
    {
        
        try{
            $order=Order::create($request->validated());
            $order->notify(new OrderCreatedNotification($order));
        }
        catch(Exception $e) {
            return response()->json(["status"=>"error","message"=>$e->getMessage()//__("internal_error")
        ],
            500);
        }
        return response()->json(["status"=>"ok"],200);
        
    }

   
}
