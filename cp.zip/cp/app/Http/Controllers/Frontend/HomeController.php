<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use App\Http\Resources\CurrenciesResource;
use App\Models\Review;
use Illuminate\Http\Request;
use Illuminate\View\View;

class HomeController extends Controller
{
    public function Index():View
    {
        $keywords='';
        $currencies= (new CurrenciesResource(""))->toArray(new Request());
        $currencies=array_chunk($currencies,intval((count($currencies))/2));
        $reviews=Review::all();
        return view("index",compact("keywords","currencies","reviews"));
    }
}
