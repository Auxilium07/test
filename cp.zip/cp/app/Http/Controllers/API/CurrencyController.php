<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Models\Currency;
use Illuminate\Http\Request;

class CurrencyController extends Controller
{
    public function Exchange()
    {
         $fCurr=request()->get("curr1");
         $tCurr=request()->get("curr2");
         if($fCurr==null||$tCurr==null)
         {
            return response("{'status':'error','message':'Валюта должна быть выбрана'}",400);
         }
         
         $lang=request()->get("lang")?request()->get("lang"):"en";
       
        if(!$lang=="en"&&!$lang="ru")
        {
            $lang="en";
        }
       
        $q="https://api.coingecko.com/api/v3/coins/markets?vs_currency=".($lang=="en"?"usd":"rub")."&ids=".$fCurr.",".$tCurr."&order=market_cap_desc&per_page=50&page=1&sparkline=false&price_change_percentage=24h%2C7d%2C14d%2C&locale=".$lang;
        $ch = curl_init();

        // set url
        curl_setopt($ch, CURLOPT_URL, $q);
    
        //return the transfer as a string
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch,CURLOPT_USERAGENT,'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1.13) Gecko/20080311 Firefox/2.0.0.13');
    
        // $output contains the output string
        $output = curl_exec($ch);
    
        // close curl resource to free up system resources
        curl_close($ch); 
        return $output;
    }

    public function Calculate(){
        $fCurr=request()->get("curr1");
         $tCurr=request()->get("curr2");
         $amount=request()->get("amount");
         if($amount==0||$amount==null)
         {
            return response("{'status':'error','ERRORS':'Сумма не может быть меньшне 0'}",400);
         }
         if($fCurr==null||$tCurr==null)
         {
            return response("{'status':'error','ERRORS':'Сумма не может быть равна 0'}",400);
         }
         $lang=request()->get("lang")?request()->get("lang"):"en";
       
        if(!$lang=="en"&&!$lang="ru")
        {
            $lang="en";
        }
        $q="https://api.coingecko.com/api/v3/coins/markets?vs_currency=".($lang=="en"?"usd":"rub")."&ids=".$fCurr.",".$tCurr."&order=market_cap_desc&per_page=50&page=1&sparkline=false&price_change_percentage=24h%2C7d%2C14d%2C&locale=".$lang;
        $ch = curl_init();

        // set url
        curl_setopt($ch, CURLOPT_URL, $q);
    
        //return the transfer as a string
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch,CURLOPT_USERAGENT,'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1.13) Gecko/20080311 Firefox/2.0.0.13');
    
        // $output contains the output string
        $output = curl_exec($ch);
    
        // close curl resource to free up system resources
        curl_close($ch); 
        
        $output=json_decode($output,true);
        $one=$output[0]['current_price'];
        $two=$output[1]['current_price'];
        $one*=floatval($amount);
        $result=$one/$two;
        
        return response()->json(['status'=>'ok','AMOUNT'=>$result,'COMMISSION'=>($one*0.015)],200);
    }
}
