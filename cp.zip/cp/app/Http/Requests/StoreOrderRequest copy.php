<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StoreOrderRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {

        return [
            "wallet"=>"required|string",
            "email"=>"required|email:rfc,dns",
            "phone"=>"required|string",
            "amount"=>"required|numeric",
            "amount_to"=>"required|numeric",
            "currency_one"=>"required|string",
            "currency_two"=>"required|string",
            "firstname"=>"string|null",
            "middlename"=>"string|null",
            "lastname"=>"string|null",
            'status'=>'integer|null'
            //
        ];
    }
}
