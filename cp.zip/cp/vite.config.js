import { defineConfig } from 'vite';
import laravel from 'laravel-vite-plugin';

export default defineConfig({
    plugins: [
        laravel({
            input: ['resources/css/app.css','resources/js/sb-admin-2.min.js','resources/js/bootstrap.js','resources/js/back.js','resources/css/sb-admin-2.min.css','resources/css/back.css', 'resources/js/app.js', 'resources/js/jquery-ui.min.js','resources/js/chosen.jquery.min.js','resources/css/chosen.css'],
            refresh: true,
        }),
    ],
});
