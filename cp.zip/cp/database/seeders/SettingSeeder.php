<?php

namespace Database\Seeders;

use App\Models\Setting;
use Illuminate\Database\Seeder;

class SettingSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Setting::create(['display_name' => 'Заголовок сайту', 'key' => 'site_title', 'value' => 'Вша назва', 'type' => 'text', 'section' => 'Загальні']);
        Setting::create(['display_name' => 'Слоган сайту', 'key' => 'site_slogan', 'value' => 'Ваш слоган', 'type' => 'text', 'section' => 'Загальні']);
        Setting::create(['display_name' => 'Опис сайту', 'key' => 'site_description', 'value' => 'Ваш опис', 'type' => 'text', 'section' => 'Загальні']);
        Setting::create(['display_name' => 'Ключеві слова сайту', 'key' => 'site_keywords', 'value' => 'Вакші ключеві слова', 'type' => 'text', 'section' => 'Загальні']);
  
        Setting::create(['display_name' => 'Статус сайту', 'key' => 'site_status', 'value' => 'Active', 'type' => 'text', 'section' => 'Загальні']);
        Setting::create(['display_name' => 'Загаловок адмін панелі', 'key' => 'admin_title', 'value' => 'Cart White', 'type' => 'text', 'section' => 'Загальні']);
        
    }
}
