<?php

namespace Database\Seeders;

use App\Models\Review;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class ReviewSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        Review::create(["first_name"=>"Mohamad","last_name"=>"Alshawaf","date"=>"2024/09/05","content"=>'Fast and legit, I recommend']);
        Review::create(["first_name"=>"J","last_name"=>"walker","date"=>"2024/09/04","content"=>'Thanks team amazing work very quick and efficient']);
        Review::create(["first_name"=>"Emmanuel","date"=>"2024/08/28","content"=>'Fast and easy']);
        Review::create(["first_name"=>"Key","date"=>"2024/08/06","content"=>'Thanks! Great service as always!']);  
        Review::create(["first_name"=>"nico","date"=>"2024/07/29","content"=>'Thanks bro, arrived in 5 mintues. usdt to skrill']);  
        Review::create(["first_name"=>"Olexander","date"=>"2024/07/19","content"=>'Cool']);  
        Review::create(["first_name"=>"Olexander","date"=>"2024/07/19","content"=>'Trustworthy']);     
        Review::create(["first_name"=>"Antonio","date"=>"2024/07/15","content"=>'fast and easy']);   
        Review::create(["first_name"=>"Antony","date"=>"2024/07/14","content"=>'Fast and easy, take around 12 min for appears in my acc']);   
        Review::create(["first_name"=>"Дмитрий","date"=>"2024/09/07","content"=>'Всё пришло удобно , быстро ,оператор  на связи, была ошибка с моей стороны все уладили , рекомендую']);
    }
}
