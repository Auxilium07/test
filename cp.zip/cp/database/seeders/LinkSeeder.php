<?php

namespace Database\Seeders;

use App\Models\Link;
use Illuminate\Database\Seeder;

class LinkSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Link::whereStatus(true)->create([
            'title' => 'Заявки',
            'as' => 'Orders',
            'to' => 'admin.orders.index',
            'icon' => 'fas fa-shopping-basket',
            'permission_title' => 'access_order',
            'status' => 1,
        ]);

        Link::whereStatus(true)->create([
            'title' => 'Користувачі',
            'as' => 'User',
            'to' => 'admin.users.index',
            'icon' => 'fas fa-users',
            'permission_title' => 'access_user',
            'status' => 1,
        ]);


        Link::whereStatus(true)->create([
            'title' => 'Відгуки',
            'as' => 'Review',
            'to' => 'admin.reviews.index',
            'icon' => 'fas fa-comment',
            'permission_title' => 'access_review',
            'status' => 1,
        ]);

    }
}
