<div>
    <form wire:submit="save" class="d-flex">
        <input type="hidden" wire:model="order_id" value="<?php echo e($order_id); ?>">
        <select class="form-control"  wire:model="status" name='status' wire:change="save" style="outline-style: none;">
        <option disabled <?php echo e(!in_array($current_status,array_keys($orderStatusArray))?"selected":''); ?>> Оберіть статус </option>
        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $orderStatusArray; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($key); ?>" <?php echo e($key== $current_status?'selected':''); ?>><?php echo e($value); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
    </select>
    
    </form>
        <?php
        $__scriptKey = '998077490-0';
        ob_start();
    ?>
<script>
     document.addEventListener('livewire:initialized', function () {
            $selected=$("[name='status'] option[value='<?php echo e($current_status); ?>']")[0].selected=true;
        })
</script>
    <?php
        $__output = ob_get_clean();

        \Livewire\store($this)->push('scripts', $__output, $__scriptKey)
    ?>

</div>
<?php /**PATH /Users/antonrybalkin/Projects/cp/resources/views/livewire/changestatus.blade.php ENDPATH**/ ?>