<?php $__env->startSection('content'); ?>
    <div class="mb-4 shadow card">
        <div class="py-3 card-header d-flex">
            <h6 class="m-0 font-weight-bold text-primary">
                Користувачі
            </h6>
            <div class="ml-auto">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create_user')): ?>
                    <a href="<?php echo e(route('admin.users.create')); ?>" class="btn btn-primary">
                    <span class="icon text-white-50">
                        <i class="fa fa-plus"></i>
                    </span>
                        <span class="text">Додати користувача</span>
                    </a>
                <?php endif; ?>
            </div>
        </div>
        <?php echo $__env->make('partials.backend.filter', ['model' => route('admin.users.index')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                <tr>
                    <th>ID</th>
                    <th>Аватар</th>
                    <th>Повне імʼя та логін</th>
                    <th>Пошта на номер телфона</th>
                    <th>Статус</th>
                    <th>Зареєструвався в</th>
                    <th class="text-center" style="width: 30px;">Action</th>
                </tr>
                </thead>
                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($user->id); ?></td>
                        <td>
                            <?php if($user->user_image): ?>
                                <img src="<?php echo e(asset('storage/images/users/' . $user->user_image)); ?>" alt="<?php echo e($user->full_name); ?>" class="img-profile rounded-circle">
                            <?php else: ?>
                                <img src="<?php echo e(asset('img/avatar.png')); ?>" alt="<?php echo e($user->full_name); ?>" width="60" height="60">
                            <?php endif; ?>
                        </td>
                        <td>
                            <a href="<?php echo e(route('admin.users.show', $user->id)); ?>">
                                <?php echo e($user->full_name); ?>

                            </a><br>
                            <strong>( <?php echo e($user->username); ?> )</strong>
                        </td>
                        <td><?php echo e($user->email); ?><br>
                            <?php echo e($user->phone); ?>

                        </td>
                        <td><?php echo e($user->status); ?></td>
                        <td><?php echo e($user->created_at ? $user->created_at->format('Y-m-d') : ''); ?></td>
                        <td>
                            <div class="btn-group btn-group-sm">
                                <a href="<?php echo e(route('admin.users.edit', $user)); ?>" class="btn btn-sm btn-primary">
                                    <i class="fa fa-edit"></i>
                                </a>
                                <a href="javascript:void(0);"
                                   onclick="if (confirm('Are you sure to delete this record?'))
                                       {document.getElementById('delete-tag-<?php echo e($user->id); ?>').submit();} else {return false;}"
                                   class="btn btn-sm btn-danger">
                                    <i class="fa fa-trash"></i>
                                </a>
                            </div>
                            <form action="<?php echo e(route('admin.users.destroy', $user)); ?>"
                                  method="POST"
                                  id="delete-tag-<?php echo e($user->id); ?>" class="d-none">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td class="text-center" colspan="6">Користувачів не знайдено.</td>
                    </tr>
                <?php endif; ?>
                </tbody>
                <tfoot>
                <tr>
                    <td colspan="6">
                        <div class="float-right">
                            <?php echo $users->appends(request()->all())->links(); ?>

                        </div>
                    </td>
                </tr>
                </tfoot>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/backend/users/index.blade.php ENDPATH**/ ?>