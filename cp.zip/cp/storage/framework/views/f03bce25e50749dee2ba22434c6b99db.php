<div class="py-3">
   
    <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="w-full px-3 border">
            <div class="w-full justify-content-between d-flex align-content-between">
                <div><?php echo e($message->user->username); ?> : <?php echo e($message->created_at->format('d-m-Y h:i a')); ?></div>
                <div> 
                           
                                  <button type="button" wire:click="delete(<?php echo e($message->id); ?>,<?php echo e($order_id); ?>)"
                               class="btn btn-sm btn-danger">
                                <i class="fa fa-trash"></i>
                            </button>
                            
                            
                        </div>
                        </div>
            
            <p class="p-2 border">
          <?php echo e($message->message); ?></p>
        </div>
       
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="px-3">
            Попередніх коментарів немає
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    
</div><?php /**PATH /Users/antonrybalkin/Projects/cp/resources/views/livewire/messages.blade.php ENDPATH**/ ?>