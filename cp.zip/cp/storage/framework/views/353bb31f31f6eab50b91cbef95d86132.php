<div class="card-body">
    <form action="<?php echo e($model); ?>" method="GET">
        <div class="row">
            <div class="col-2">
                <div class="form-group">
                    <label for="keyword">Ключові слова</label>
                    <input type="text"
                           class="form-control"
                           name="keyword"
                           id="keyword"
                           placeholder="Введіть для пошуку"
                           value="<?php echo e(old('keyword'), request()->input('keyword')); ?>">
                </div>
            </div>
            <div class="col-2">
                <div class="form-group">
                    <label for="status">Статус</label>
                    <select name="status" id="status" class="form-control">
                        <option value="">---</option>
                        <option value="0" <?php echo e(old('status', request()->input('status') == '0' ? 'selected' : '')); ?>>Деактивована</option>
                        <option value="1" <?php echo e(old('status', request()->input('status') == '1' ? 'selected' : '')); ?>>Активована</option>
                    </select>
                </div>
            </div>
            <div class="col-2">
                <div class="form-group">
                    <label for="sortBy">Сортувати по параметру</label>
                    <select name="sortBy" id="sortBy" class="form-control">
                        <option value="">---</option>
                        <option value="id" <?php echo e(old('sortBy', request()->input('sortBy') == 'id' ? 'selected' : '')); ?>>ID</option>
                        <option value="name" <?php echo e(old('sortBy', request()->input('sortBy') == 'name' ? 'selected' : '')); ?>>Назва</option>
                        <option value="created_at" <?php echo e(old('sortBy', request()->input('sortBy') == 'created_at' ? 'selected' : '')); ?>>Створено</option>
                    </select>
                </div>
            </div>
            <div class="col-2">
                <div class="form-group">
                    <label for="orderBy">Порядок сортування</label>
                    <select name="orderBy" id="orderBy" class="form-control">
                        <option value="">---</option>
                        <option value="asc" <?php echo e(old('orderBy', request()->input('orderBy') == 'asc' ? 'selected' : '')); ?>>за зростанням</option>
                        <option value="desc" <?php echo e(old('orderBy', request()->input('orderBy') == 'desc' ? 'selected' : '')); ?>>за спаданням</option>
                    </select>
                </div>
            </div>
            <div class="col-2">
                <div class="form-group">
                    <label for="limitBy">Показувати по</label>
                    <select name="limitBy" id="limitBy" class="form-control">
                        <option value="">---</option>
                        <option value="10" <?php echo e(old('limitBy', request()->input('limitBy') == '10' ? 'selected' : '')); ?>>10</option>
                        <option value="20" <?php echo e(old('limitBy', request()->input('limitBy') == '20' ? 'selected' : '')); ?>>20</option>
                        <option value="50" <?php echo e(old('limitBy', request()->input('limitBy') == '50' ? 'selected' : '')); ?>>50</option>
                        <option value="100" <?php echo e(old('limitBy', request()->input('limitBy') == '100' ? 'selected' : '')); ?>>100</option>
                    </select>
                </div>
            </div>
            <div class="col-1">
                <div class="form-group">
                    <button type="submit" name="submit" class="btn btn-link">Шукати</button>
                </div>
            </div>
        </div>
    </form>
</div>
<?php /**PATH /Users/antonrybalkin/Projects/cp/resources/views/partials/backend/filter.blade.php ENDPATH**/ ?>