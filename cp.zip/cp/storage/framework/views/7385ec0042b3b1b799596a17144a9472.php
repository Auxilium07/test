<div>
    <a class="nav-link dropdown-toggle" href="#" id="alertsDropdown" role="button"
       data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        <i class="fas fa-bell fa-fw"></i>
        <!-- Counter - Alerts -->
        <span class="badge badge-danger badge-counter"><?php echo e(isset($unReadNotificationsCount)?$unReadNotificationsCount:'-'); ?></span>
    </a>
    <!-- Dropdown - Alerts -->
    <div class="shadow dropdown-list dropdown-menu dropdown-menu-right animated--grow-in"
         aria-labelledby="alertsDropdown">
        <h6 class="dropdown-header">
            Центр сповіщень
        </h6>
        <!--[if BLOCK]><![endif]--><?php if(isset($unReadNotifications )): ?>
            
        <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $unReadNotifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <a class="dropdown-item d-flex align-items-center" wire:click="markAsRead('<?php echo e($notification->id); ?>')">
            <div class="mr-3">
                <div class="icon-circle bg-primary">
                    <i class="text-white fas fa-file-alt"></i>
                </div>
            </div>
            <div>

                <div class="text-gray-500 small"><?php echo e($notification->data['created_date']); ?></div>
               
                    <span class="font-weight-bold">
                        Нова заявка
                    </span>
                
            </div>
        </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="text-center dropdown-item">Повідомлень не знайдено!</div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        

    </div>
</div>
<?php /**PATH /Users/antonrybalkin/Projects/cp/resources/views/livewire/backend/notification-component.blade.php ENDPATH**/ ?>