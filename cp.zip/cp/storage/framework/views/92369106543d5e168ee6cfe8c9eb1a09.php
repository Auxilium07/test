<div>
     <!-- Nav Item - Pages Collapse Menu -->
     <!--[if BLOCK]><![endif]--><?php if($admin_side_menu): ?>
    
     <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $admin_side_menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
  
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check($link->permission_title)): ?>
       
         <!--[if BLOCK]><![endif]--><?php if(in_array($link->to, $routes_name)): ?>
         <div class="nav-item <?php echo e(Request::url() == route($link->to) ? "active":""); ?>">
                     <a class="nav-link" href="<?php echo e(route($link->to)); ?>">
                         <i class="<?php echo e($link->icon); ?>"></i>
                         <?php echo e($link->title); ?>

                     </a>
                 <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </div>

 <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
<?php endif; ?><!--[if ENDBLOCK]><![endif]-->
   
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</div><?php /**PATH /var/www/html/resources/views/livewire/sidemenu.blade.php ENDPATH**/ ?>