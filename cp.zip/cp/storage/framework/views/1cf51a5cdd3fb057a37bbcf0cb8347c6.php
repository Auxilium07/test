<?php $__env->startSection('styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('backend/vendor/datepicker/themes/classic.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('backend/vendor/datepicker/themes/classic.date.css')); ?>">
<style>
    .picker__select--month,
    .picker__select--year {
        padding: 0 !important;
    }
</style>
<?php $__env->stopSection(); ?>
<div class="card-body">
    <form action="<?php echo e(route('admin.orders.index')); ?>" method="GET">
        <div class="row">
            <div class="col-2">
                <div class="form-group">
                    <label for="">Пошук за словами</label>
                    <input type="text"
                           class="form-control"
                           name="keyword"
                           placeholder="Введіть для пошуку"
                           value="<?php echo e(old('keyword'), request()->input('keyword')); ?>">
                </div>
            </div>
            <div class="col-2">
                <div class="form-group">
                    <label for="">Статус заявки</label>
                    <select name="status" class="form-control">
                        <option value="">---</option>
                        <option value="0" <?php echo e(old('status', request()->input('status') == '0' ? 'selected' : '')); ?>>Необроблена</option>
                        <option value="1" <?php echo e(old('status', request()->input('status') == '1' ? 'selected' : '')); ?>>Оброблений</option>
                        <option value="2" <?php echo e(old('status', request()->input('status') == '2' ? 'selected' : '')); ?>>Обробляєтся</option>
                        <option value="3" <?php echo e(old('status', request()->input('status') == '3' ? 'selected' : '')); ?>>Закритий</option>
                        <option value="4" <?php echo e(old('status', request()->input('status') == '4' ? 'selected' : '')); ?>>На паузі</option>

                    </select>
                </div>
            </div>
            <div class="col-2">
                <div class="form-group">
                    <label for="">Сортувати за колонками</label>
                    <select name="sortBy" class="form-control">
                        <option value="">---</option>
                        <option value="id" <?php echo e(old('sortBy', request()->input('sortBy') == 'id' ? 'selected' : '')); ?>>ID</option>
                        <option value="name" <?php echo e(old('sortBy', request()->input('sortBy') == 'name' ? 'selected' : '')); ?>>Назва</option>
                        <option value="created_at" <?php echo e(old('sortBy', request()->input('sortBy') == 'created_at' ? 'selected' : '')); ?>>Додано в</option>
                    </select>
                </div>
            </div>
            <div class="col-2">
                <div class="form-group">
                    <label for="">Порядком</label>
                    <select name="orderBy" class="form-control">
                        <option value="">---</option>
                        <option value="asc" <?php echo e(old('orderBy', request()->input('orderBy') == 'asc' ? 'selected' : '')); ?>>за зростанням</option>
                        <option value="desc" <?php echo e(old('orderBy', request()->input('orderBy') == 'desc' ? 'selected' : '')); ?>>за спаданням</option>
                    </select>
                </div>
            </div>
            <div class="col-2">
                <div class="form-group">
                    <label for="">Ліміт видачі</label>
                    <select name="limitBy" class="form-control">
                        <option value="">---</option>
                        <option value="10" <?php echo e(old('limitBy', request()->input('limitBy') == '10' ? 'selected' : '')); ?>>10</option>
                        <option value="20" <?php echo e(old('limitBy', request()->input('limitBy') == '20' ? 'selected' : '')); ?>>20</option>
                        <option value="50" <?php echo e(old('limitBy', request()->input('limitBy') == '50' ? 'selected' : '')); ?>>50</option>
                        <option value="100" <?php echo e(old('limitBy', request()->input('limitBy') == '100' ? 'selected' : '')); ?>>100</option>
                    </select>
                </div>
            </div>
            
        </div>
        <div class="d-flex justify-items-center align-items-center">
            <div class="col-2">
                <div class="form-group">
                    <label for="">Вибірка за</label>
                    <select name="filterBy" class="form-control">
                        <option value="0">---</option>
                        <option value="1" <?php echo e(old('filterBy', request()->input('filterBy') == '1' ? 'selected' : '')); ?>>Останній рік</option>
                        <option value="2" <?php echo e(old('filterBy', request()->input('filterBy') == '2' ? 'selected' : '')); ?>>Останню чертверть</option>
                        <option value="3" <?php echo e(old('filterBy', request()->input('filterBy') == '3' ? 'selected' : '')); ?>>Останній місяць</option>
                        <option value="4" <?php echo e(old('filterBy', request()->input('filterBy') == '4' ? 'selected' : '')); ?>>Останній тиждень</option>
                        <option value="5" <?php echo e(old('filterBy', request()->input('filterBy') == '5' ? 'selected' : '')); ?>>За вчорашній день</option>
                        <option value="6" <?php echo e(old('filterBy', request()->input('filterBy') == '6' ? 'selected' : '')); ?>>Сьогодні</option>
                    </select>
                </div>
            </div>
            <div class="col-2">
                <div class="form-group">
                <div class="form-group">
                            <label for="start_date">Починаючи з</label>
                            <input class="form-control" id="start_date"  type="text" name="start_date" value="<?php echo e(old('start_date'), request()->input('start_date')); ?>">
                </div>
                </div>
            </div>
            <div class="col-2">
                <div class="form-group">
                <label for="expire_date">Закінчиючі по</label>
                <input class="form-control" id="expire_date" type="text" name="expire_date" value="<?php echo e(old('expire_date'), request()->input('expire_date')); ?>">
                    </div>
                
            </div>

            <div class="col-2">
                <div class="form-group">
                    <button type="submit" name="submit" class="btn btn-link">Пошук</button>
                </div>
            </div>
        </div>

    </form>
</div>
<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('backend/vendor/datepicker/picker.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/vendor/datepicker/picker.date.js')); ?>"></script>
    <script>
        $(document).ready(function() {
    
            $("#start_date").pickadate({
                format: 'yyyy-mm-dd',
                selectMonths: true, // creates a dropdown to control month
                selectYears: true, // Creates a dropdown to control year
                clear: 'Clear',
                close: 'Ok',
                closeOnSelect: true, // Close upon selecting a date
            });
    
            var startdate = $('#start_date').pickadate('picker');
            var enddate = $('#expire_date').pickadate('picker');
    
            $("#start_date").change(function () {
                selected_ci_date = "";
                selected_ci_date = $('#start_date').val();
                if (selected_ci_date != null) {
                    var cidate = new Date(selected_ci_date);
                    console.log(cidate);
                    min_codate = "";
                    min_codate = new Date();
                    min_codate.setDate(cidate.getDate()+1);
                    console.log(min_codate);
                    $('#expire_date').pickadate('picker').set('min', min_codate);
    
                }
            });
    
            $('#expire_date').pickadate({
                format: 'yyyy-mm-dd',
                min: new Date(),
                selectMonths: true, // creates a dropdown to control month
                selectYears: true, // Creates a dropdown to control year
                clear: 'Clear',
                close: 'Ok',
                closeOnSelect: true, // Close upon selecting a date
            });
        });
    </script>
<?php $__env->stopSection(); ?><?php /**PATH /var/www/html/resources/views/backend/orders/filter.blade.php ENDPATH**/ ?>