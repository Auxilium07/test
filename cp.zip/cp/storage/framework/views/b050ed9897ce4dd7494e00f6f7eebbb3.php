<?php $__env->startSection('content'); ?>
    <div class="mb-4 shadow card">
        
        <div class="py-3 card-header">
            Сторінка користувача
           
            
            <div class="mt-1 d-flex align-items-center">
                <?php if($user->user_image): ?>
                <img class="mr-5" src="<?php echo e(asset('storage/images/users/' . $user->user_image)); ?>" alt="" style="width: 70px;">
            <?php else: ?>
                <img class="mr-5" src="<?php echo e(asset('img/avatar.png')); ?>" alt="<?php echo e($user->full_name); ?>" style="width: 70px;">
            <?php endif; ?>
                <?php echo e($user->full_name); ?>

            <div class="ml-auto">
                <a href="<?php echo e(route('admin.users.index')); ?>" class="btn btn-primary">
                    <span class="text">До користувачів</span>
                </a>
            </div>
            </div>
        </div>
        <div class="table-responsive">
            <table class="table table-hover">
                <tbody>
                <tr>
                    <th>ID</th>
                    <td><?php echo e($user->id); ?></td>
                    <th>Імʼя</th>
                    <td><?php echo e($user->first_name); ?></td>
                    <th>Прізвище</th>
                    <td><?php echo e($user->last_name); ?></td>
                </tr>
                <tr>
                    <th>Email</th>
                    <td><?php echo e($user->email==null?"-":$user->email); ?></td>
                    <th>Username</th>
                    <td><?php echo e($user->username); ?></td>
                    <td>Номер телефона</td>
                    <td><?php echo e($user->phone==null?"-":$user->phone); ?></td>
                </tr>
                <tr>
                    <th>Статус</th>
                    <td><?php echo e($user->status); ?></td>
                    <td>Email підтвреджений</td>
                    <td><?php echo e($user->email_verified_at ? $user->email_verified_at->format('Y-m-d') : "-"); ?></td>
                    <td>Зареєстрований</td>
                    <td><?php echo e($user->created_at ? $user->created_at->format('Y-m-d') : "-"); ?></td>
                </tr>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/antonrybalkin/Projects/cp/resources/views/backend/users/show.blade.php ENDPATH**/ ?>