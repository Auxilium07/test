</div>
<div class="footer_clear"></div>
            
<footer>
    <div class="container">
        <div class="pull-right">
                <ul class="bottom-menu">
            <li><a href="/tеrms_of_service/">User agreement</a></li>
            <li><a href="/privacy_policy/">AML policy</a></li>
    </ul>

        </div>

            <ul class="bottom-menu">
            <li><a href="/reviews/">Reviews</a></li>
            <li><a href="/contacts/">Contact us</a></li>
    </ul>
    </div>
    <div class="text-center bg-blue-middle2">
© 2024, <?php echo e(env('APP_NAME')); ?>, <?php echo e(__("rights")); ?>

</div>
<br>		</footer>



<!-- End of LiveChat code -->
</body><!-- Start of LiveChat (www.livechat.com) code --></html><?php /**PATH /Users/antonrybalkin/Projects/cp/front_crypto/resources/views/parts/footer.blade.php ENDPATH**/ ?>