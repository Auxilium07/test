<?php $__env->startSection('content'); ?>
    <!-- Page Heading -->
    <div class="mb-4 d-sm-flex align-items-center justify-content-between">
        <h1 class="mb-0 text-gray-800 h3">Адмін панель</h1>
        <p class="ml-auto col-6">Оберіть розділ</p>
    </div>


    

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/antonrybalkin/Projects/cp/resources/views/backend/index.blade.php ENDPATH**/ ?>