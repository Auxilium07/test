<nav class="mb-4 bg-white shadow navbar navbar-expand navbar-light topbar static-top">

    <!-- Sidebar Toggle (Topbar) -->
    <button id="sidebarToggleTop" class="mr-3 btn btn-link d-md-none rounded-circle">
        <i class="fa fa-bars"></i>
    </button>

    <!-- Topbar Navbar -->
    <ul class="ml-auto navbar-nav">

        <!-- Nav Item - Alerts -->
        <li class="mx-1 nav-item dropdown no-arrow">
            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('backend.notification-component', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-3166292736-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
        </li>

        <!-- Nav Item - Messages -->
        

        <!-- Supervisor link -->

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('access_link')): ?>
            <li class="nav-item">
                <a class="nav-link text-dark" href="<?php echo e(route('admin.links.index')); ?>">
                    Посилання
                </a>
            </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('access_supervisor')): ?>
            <li class="nav-item">
                <a class="nav-link text-dark" href="<?php echo e(route('admin.supervisors.index')); ?>">
                    Модератори
                </a>
            </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('access_setting')): ?>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('admin.settings.index')); ?>">
                    <span>
                        Налаштування
                    </span></a>
            </li>
        <?php endif; ?>

        <div class="topbar-divider d-none d-sm-block"></div>

        <!-- Nav Item - User Information -->
        <li class="nav-item dropdown no-arrow">
            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button"
               data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <?php if(auth()->guard()->check()): ?>
                    <span class="mr-2 text-gray-600 d-none d-lg-inline small"><?php echo e(auth()->user()->first_name); ?></span>
                <?php endif; ?>
                <?php if(auth()->user()->user_image): ?>
                    <img class="img-profile rounded-circle" src="<?php echo e(asset('storage/images/users/' . auth()->user()->user_image)); ?>"
                         alt="<?php echo e(auth()->user()->full_name); ?>">
                <?php else: ?>
                    <img class="img-profile rounded-circle" src="<?php echo e(asset('img/avatar.png')); ?>" alt="">
                <?php endif; ?>
            </a>
            <!-- Dropdown - User Information -->
            <div class="shadow dropdown-menu dropdown-menu-right animated--grow-in"
                 aria-labelledby="userDropdown">
                <a class="dropdown-item" href="<?php echo e(route('admin.account_setting')); ?>">
                    <i class="mr-2 text-gray-400 fas fa-user fa-sm fa-fw"></i>
                    Профіль
                </a>

                <div class="dropdown-divider"></div>

                <?php if(auth()->guard()->check()): ?>
                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">
                    <i class="mr-2 text-gray-400 fas fa-sign-out-alt fa-sm fa-fw"></i>
                    Вийти
                </a>
                <?php endif; ?>
            </div>
        </li>

    </ul>

</nav>
<?php /**PATH /var/www/html/resources/views/partials/backend/navbar.blade.php ENDPATH**/ ?>