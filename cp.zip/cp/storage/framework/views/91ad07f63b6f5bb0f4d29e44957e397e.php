<?php echo $__env->make("parts/header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<section class="bg-white">
    <div class="container">


<div class="row">
<div class="col-xs-10 col-xs-offset-1">
<div class="long-text-page">
Money laundering refers to actions aimed at turning money or other tangible assets obtained from illegal activities (terrorism, drug trafficking, illegal arms trade, corruption, human trafficking, etc.) into money and assets that have a legal status. Such actions are taken to make it impossible to trace the criminal or illegal origin of money.<br><br>

The aim of anti-money laundering is to ensure that clients involved in financial transactions involving the OpenChange site are identified to a reasonable standard, with a minimum set of identification data for law-abiding clients. In accordance with the requirements of international law, the OpenChange Company has developed an internal policy to combat the financing of terrorism and the legalization of proceeds from crime. OpenChange carefully monitors suspicious activities and transactions and promptly reports such activities to the appropriate authorities.<br><br>

AML and KYC verification<br>
1) The service conducts AML and KYC verification of incoming transactions according to its own algorithms.<br>
2) AML and KYC verification includes the use of specialized services for analyzing cryptocurrency transactions for the presence of funds that have high risks for the Service.<br>
3) If the analysis of the incoming transaction revealed an excess of the allowable values (the values ​​are indicated at the bottom of this AML and KYC Policy), the funds are subjected to additional analysis:<br>
4) If, as a result of additional analysis, the connection of the received funds with money laundering or criminal activity is revealed:<br>
4.1) Application processing is suspended <br>
4.2) Through an internal chat in the application, the User is requested to provide documents, photo / video materials, explanations of the origin of funds.<br>
4.3) If verification is successful, funds are returned to the client to the agreed address minus the transaction sending fee and the Service operation fee of 1% (min. 40 USD, max. 100 USD).<br>
5) The User undertakes to provide the requested photos/videos, wait for the verification decision and not make any claims against the Service.<br>
5.1) If this requirement is violated, we will be forced to increase the maximum fee for refunds from 100 USD to 200 USD to cover lost income and reputational risks for the Service.<br><br>

In its activities, OpenChange cooperates with cryptocurrency exchanges, to which funds sent by Users are credited. If the security service of the exchange receives a request from law enforcement agencies to provide information about the User, OpenChange reserves the right to transfer all data about the User:<br>
- personally to law enforcement agencies<br>
- through the security service of the cryptocurrency exchange<br>
- via AML officer<br><br>

OpenChange reserves the right to refuse a transaction at any stage if, in the company's opinion, the transaction is related in any way to money laundering or criminal activity. In accordance with international law, OpenChange is not required to inform the Client that its activities have been reported to the relevant authorities as suspicious.<br><br>

OpenChange is constantly updating the electronic system for verifying transactions and customer identification data in accordance with all current legal regulations, and also organizes trainings for its employees regarding the fight against money laundering.<br><br>

Acceptable values of risk categories:<ul style="text-align: justify;">
<li>Darknet Marketplace or Darknet Service - 0%</li>
<li>Illegal Service - 0%</li>
<li>Gambling - 0%</li>
<li>Drugs - 0%</li>
<li>Child Abuse - 0%</li>
<li>Stolen Coins or Credit Cards - 0%</li>
<li>Ransom - 0%</li>
<li>Malware (excluding Ransom) - 0%</li>
<li>Blackmail - 0%</li>
<li>Terrorism - 0%</li>
<li>Illegal migration - 0%</li>
<li>Human trafficking - 0%</li>
<li>Smuggling - 0%</li>
<li>Enforcement Action - 0%</li>
<li>High Risk country and Sanction country - 0%</li>
<li>Fake documents, fake document rendering - 0%</li>
<li>Illegal weapons - 0%</li>
<li>Politically exposed person, corruption - 0%</li>
<li>DDOS service - 0%</li>
<li>Phishing service - 0%</li>
<li>Scam - &lt;5%</li>
<li>Scam ICO - 0%</li>
<li>State bodies - 0%</li>
<li>Personal data US or EU - 0%</li>
<li>Personal data RU or CIS - &lt;10%</li>
<li>Personal data other - &lt;10%</li>
<li>Precursors - &lt;10%</li>
<li>China precursors manufacturing - &lt;10%</li>
<li>Stolen DataBase - &lt;10%</li>
<li>Paramilitary organization - &lt;10%</li>
<li>Cracked software - &lt;10%</li>
<li>Laundering of money - &lt;10%</li>
<li>Illegal financial transactions - &lt;10%</li>
<li>Bribge - &lt;25%</li>
<li>Mixing Service - &lt;25%</li>
<li>Online Marketplace - &lt;25%</li>
<li>OTC Exchange With High ML Risk - &lt;50%</li>
<li>OTC Exchange With Very High ML Risk - &lt;50%</li>
<li>Exchange With High ML Risk - &lt;50%</li>
<li>Exchange With Very High ML Risk - &lt;50%</li>
<li>Fraudulent Exchange - 0%</li>
<li>DEX (excluding Bridges) - &lt;50%</li>
<li>P2P Exchange With High ML Risk - &lt;50%</li>
<li>P2P Exchange With Very High ML Risk - &lt;50%</li>
<li>ATM - &lt;50%</li></ul>			</div>
</div>
</div>
                </div>
</section>
<?php echo $__env->make("parts/footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/antonrybalkin/Projects/cp/front_crypto/resources/views/privacy.blade.php ENDPATH**/ ?>