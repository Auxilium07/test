<?php $__env->startSection('styles'); ?>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/css/select2.min.css" integrity="sha512-nMNlpuaDPrqlEls3IX/Q56H36qvBASwb3ipuo3MxeWbsQB1881ox0cRv7UPTgBlriqoynt35KjEwgGUeUXIPnw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="mb-4 shadow card">
        <div class="py-3 card-header d-flex">
            <h6 class="m-0 font-weight-bold text-primary">Заявки №(<?php echo e($order->id); ?>)</h6>
            <div class="ml-auto d-flex">
                <a href="<?php echo e(route('admin.orders.show', $order)); ?>" class="mr-4 btn btn-sm btn-primary">
                    <span>Повернутись до заявки</span>
                </a>
            </div>
        </div>
        <form class="d-flex" method="POST" action="<?php echo e(route('admin.order.update_order',$order)); ?>">
            <?php echo method_field('PATCH'); ?>
            <?php echo csrf_field(); ?>
            <div class="col">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <tbody>
                        <tr class="my-4">
                            <th>Id</th>
                            <td><?php echo e($order->id); ?></td>
                            <th>Відповідальний</th>
                            <td>
                               
                                <?php if($order->users()->count()>0&&$order->lastuser()!=null): ?>
                                    <div>Наразі обраний: <a href="<?php echo e(route('admin.users.show', $order->lastuser()->user_id)); ?>"><?php echo e($order->lastuser()->user()->username); ?></a></div>
                                <?php endif; ?>
                                <div class="d-flex flex-column">
                                <select class="form-control w-100"  name="user_id" style="outline-style: none;">
                                    <option value=""> Оберіть відповідального </option>
                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($user->id); ?>" <?php echo e($order->lastuser()!=null&&$order->lastuser()->id==$user->id?"selected":null); ?>><?php echo e($user->username); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                
                                <?php $__errorArgs = ['user_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <span class="text-gray-500 display-6" ><?php echo e($message); ?></span>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
                               
                            </td>
                           
                        </tr>
                        <tr>
                            <th>Прізвище</th>
                            <td>
                                <div class="mb-3 input-group">
                                    <input type="text" class="form-control w-100"  name='lastname' value="<?php echo e($order->lastname); ?>" placeholder="Введіть прізвище"  >
                                    <?php $__errorArgs = ['lastname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-gray-500 display-6 " ><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </td>
                            <th>Імʼя</th>
                            <td>
                                <div class="mb-3 input-group d-flex flex-column">
                                    
                                    <input type="text" class="form-control w-100"  name='firstname' value="<?php echo e($order->firstname); ?>" placeholder="Введіть імʼя" >
                                    <?php $__errorArgs = ['firstname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-gray-500 display-6 " ><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </td>
                            <tr><th>По-батькові</th>
                            <td>
                                <div class="mb-3 input-group d-flex flex-column">
                                    
                                    <input type="text" class="form-control w-100"  name='middlename' value="<?php echo e($order->middlename); ?>" placeholder="Введіть по-батькові" >
                                    <?php $__errorArgs = ['middlename'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-gray-500 display-6 " ><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </td>
                            <th>Особистий рахунок клієнта</th>
                            <td>
                                <div class="mb-3 input-group d-flex flex-column">
                                    
                                    <input type="text" class="form-control w-100"  name='wallet' value="<?php echo e($order->wallet); ?>" placeholder="Особистий рахунок клієнта" >
                                    <?php $__errorArgs = ['wallet'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-gray-500 display-6 " ><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </td>
                        </tr>
                        </tr>
                       <tr  class="my-4">
                        <th>Телефон</th>
                        <td>
                            <div class="mb-3 input-group d-flex flex-column">
                                <input type="text" class="form-control w-100"  name='phone' value="<?php echo e($order->phone); ?>" placeholder="Номер телефону" aria-label="phone" >
                               <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-gray-500 display-6 " ><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </td>
                        <th>Email</th>
                        <td>
                            <div class="mb-3 input-group d-flex flex-column">
                                
                                <input type="email" class="form-control w-100"  name='email' value="<?php echo e($order->email); ?>" placeholder="Email" aria-label="Email" >
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-gray-500 display-6 " ><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </td>
                       </tr>

                       <tr  class="my-4">
                        <th>Сумма з</th>
                        <td>
                            <div class="mb-3 input-group d-flex flex-column">
                                <input type="number" class="form-control w-100"  name='amount' value="<?php echo e($order->amount); ?>" placeholder="Введіть число"  >
                              </div>
                              <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-gray-500 display-6 " ><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </td>
                        <th>Сумма до</th>
                        <td>
                            <div class="mb-3 input-group d-flex flex-column">
                                
                                <input type="number" class="form-control w-100"  name='amount_to' value="<?php echo e($order->amount_to); ?>" placeholder="Введіть число" >
                                <?php $__errorArgs = ['amount_to'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-gray-500 display-6 " ><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </td>
                       </tr>
                       <tr  class="my-4">
                        <th>Валюта з</th>
                        <td>
                            <div class="mb-3 input-group d-flex flex-column">
                                <input type="text" class="form-control w-100"  name='currency_one' value="<?php echo e($order->currency_one); ?>" placeholder="Введіть число"  >
                                <?php $__errorArgs = ['currency_one'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-gray-500 display-6 " ><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </td>
                        <th>Валюта до</th>
                        <td>
                            <div class="mb-3 input-group d-flex flex-column">
                                
                                <input type="text" class="form-control w-100"  name='currency_two' value="<?php echo e($order->currency_two); ?>" placeholder="Введіть число" >
                               <?php $__errorArgs = ['currency_two'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-gray-500 display-6 " ><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </td>
                       </tr>
                        <tr  class="my-4">
                            <th>Дата створення</th>
                            <td><?php echo e($order->created_at->format('d-m-Y h:i a')); ?></td>
                            <th>Статус заявки</th>
                            <td><div class="form-row align-items-center">
                                <label class="sr-only" for="inlineFormInputGroupUsername">Статус заявки</label>
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <div class="input-group-text">Статус заявки</div>
                                    </div>
                                    <div class="d-flex flex-column">
                                    <select class="form-control w-100"  name="status" style="outline-style: none;">
                                        <option disabled value=""> Оберіть опцію </option>
                                        <?php $__currentLoopData = $orderStatusArray; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($key); ?>" <?php echo e($order->status==$key?"selected":null); ?>><?php echo e($value); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php $__errorArgs = ['tatus'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-gray-500 display-6 " ><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
                                </div>
                            </div></td>
                        </tr>
                        <tr>
                           <td> <button class="btn btn-primary">Зберегти</button></td>
                        </tr>
                        </tbody>
                    
                    </table>
                </div>
            </div>
           
        </form>
    </div>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/js/select2.min.js" integrity="sha512-2ImtlRlf2VVmiGZsjm9bEyhjGW4dU7B6TNwh/hx/iSByxNENtj3WVE6o/9Lj4TJeVXPi4bnOIMXFIJJAeufa0A==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script>
        $(function () {
            // select2
            function matchStart(params, data) {
                // If there are no search terms, return all of the data
                if ($.trim(params.term) === '') {
                    return data;
                }

                // Skip if there is no 'children' property
                if (typeof data.children === 'undefined') {
                    return null;
                }

                // `data.children` contains the actual options that we are matching against
                var filteredChildren = [];
                $.each(data.children, function (idx, child) {
                    if (child.text.toUpperCase().indexOf(params.term.toUpperCase()) == 0) {
                        filteredChildren.push(child);
                    }
                });

                // If we matched any of the timezone group's children, then set the matched children on the group
                // and return the group object
                if (filteredChildren.length) {
                    var modifiedData = $.extend({}, data, true);
                    modifiedData.children = filteredChildren;

                    // You can return modified objects from here
                    // This includes matching the `children` how you want in nested data sets
                    return modifiedData;
                }

                // Return `null` if the term should not be displayed
                return null;
            }

            $(".select2").select2({
                tags: true,
                closeOnSelect: false,
                minimumResultsForSearch: Infinity,
                matcher: matchStart
            });
            $("#change_btn").click(()=>{
                let constSumm=document.querySelector("#summa-const");
                let action=document.querySelector("#action");
                if(constSumm!=null)
                {
                    constSumm.remove();
                    let tmp=`<input  class="form-control w-100"  id="total" type="number" name="total" value="<?php echo e($order->total); ?>">`;
                    action.insertAdjacentHTML("beforeend",tmp);
                }
                
            })
            
        })
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/antonrybalkin/Projects/cp/resources/views/backend/orders/update_order.blade.php ENDPATH**/ ?>