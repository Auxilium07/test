<?php $__env->startSection('content'); ?>
    <div class="mb-4 shadow card">
        <div class="py-3 card-header d-flex">
            <h6 class="m-0 font-weight-bold text-primary">
                Заявки
            </h6>
            <div class="ml-auto">
                <div class="ml-auto">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create_order')): ?>
                        <a href="<?php echo e(route('admin.orders.create')); ?>" class="btn btn-primary">
                        <span class="icon text-white-50">
                            <i class="fa fa-plus"></i>
                        </span>
                            <span class="text">Нова заявка</span>
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <?php echo $__env->make('backend.orders.filter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                <tr>
                    <th>ID</th>
                    <th>Відповідальний</th>
                    <th>ПІБ замовника</th>
                    <th>Email</th>
                    <th>Телефон</th>
                    <th>Статус</th>
                    <th>Сумма</th>
                    <th>З якої валюти</th>
                    <th>В яку валюту</th>
                    <th>Дії</th>
                </tr>
                </thead>
                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="gap-2 d-flex align-content-center">
                            
                            <a href="<?php echo e(route('admin.orders.show', $order)); ?>">
                                <?php echo e($order->id); ?>

                            </a>
                        </td>
                        <td>
                            <?php if($order->user!=null): ?>
                            <?php echo e($order->user->full_name); ?>

                            <?php else: ?>
                            Не призначено
                            <?php endif; ?></td>
                            <td><?php echo e($order->lastname.' '.$order->firstname.' '.$order->middlename); ?></td>
                            <td><?php echo e($order->email); ?></td>
                            <td><?php echo e($order->phone); ?></td>
                            <td><?php echo e($order->statusText()); ?></td>
                        <td><?php echo e($order->amount_to); ?></td>
                        <td><?php echo e($order->currency_one); ?></td>
                        <td><?php echo e($order->currency_two); ?></td>
                        <td>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit_order')): ?>
                            <a href="<?php echo e(route('admin.orders.edit', $order)); ?>" class="btn btn-sm btn-primary">
                                <i class="fa fa-edit"></i>
                            </a>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete_order')): ?>
                            <a href="javascript:void(0);"
                               onclick="if (confirm('Are you sure to delete this record?'))
                                   {document.getElementById('delete-order-<?php echo e($order->id); ?>').submit();} else {return false;}"
                               class="btn btn-sm btn-danger">
                                <i class="fa fa-trash"></i>
                            </a>
                            <form action="<?php echo e(route('admin.orders.destroy', $order)); ?>"
                                  method="POST"
                                  id="delete-order-<?php echo e($order->id); ?>" class="d-none">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                            </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td class="text-center" colspan="10">Заявок в базі не знайдено.</td>
                    </tr>
                <?php endif; ?>
                </tbody>
                <tfoot>
                <tr>
                    <td colspan="10">
                        <div class="float-right">
                            <?php echo $orders->appends(request()->all())->links(); ?>

                        </div>
                    </td>
                </tr>
                </tfoot>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/antonrybalkin/Projects/cp/resources/views/backend/orders/index.blade.php ENDPATH**/ ?>