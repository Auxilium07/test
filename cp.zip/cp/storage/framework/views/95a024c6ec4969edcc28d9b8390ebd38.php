<?php echo $__env->make("parts/header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<section class="bg-white">
    <div class="container">


<div class="row">
<div class="col-xs-10 col-xs-offset-1">
<div class="long-text-page">
1. General provisions.<br>
1.1 This Agreement (hereinafter referred to as the Agreement) is a written public offer. The agreement describes the rules and conditions on the basis of which the services of the OpenChange Company are provided.<br>
1.2 The Website Administration has the right to unilaterally change the terms of this Agreement. Such changes shall take effect from the moment the new version of the Agreement is posted on the Website. If the user does not agree with the changes made, he is obliged to refuse access to the Website, stop using the materials and eth Website.<br>
<br>
2. Terms and definitions.<br>
OpenChange Company (Company) is a service that provides services for the purchase/sale/exchange of cryptocurrencies or electronic currencies.<br>
Website of the Company (Site) – https://openchange.is<br>
User - a person using the services of the Openchange Company and accepting this Agreement.<br>
Payin - transfer of cryptocurrency or electronic currency from the User to the Company.<br>
Payout - transfer of cryptocurrency or electronic currency from the Company to the User.<br>
Order - a filled electronic form on the Website for the purpose of buying / selling / exchanging cryptocurrencies or electronic currencies.<br>
Service - a service for buying / selling / exchanging cryptocurrencies or electronic currencies.<br>
Card verification is a verification that the card (or account) belongs to its owner. The conditions for checking ownership are set by the Company. The verification is performed at a time for each new account (card) of the User.<br>
<br>
3. The subject of the Agreement and the procedure for its entry into force.<br>
3.1. The subject of this agreement is the provision of the Services by the OpenChange Company for the User.<br>
3.2. The User is considered to have accepted this Agreement in the following cases:<br>
3.2.1. Creating an Order in one of the directions of exchange offered by the Company;<br>
3.2.2. Registrations on the Website.<br>
3.3. The term of the agreement is set indefinitely for the duration of the User's account.<br>
<br>
4. Services and the procedure for their providing.<br>
4.1 Ordering the services of the OpenChange Company is carried out by the User by creating an Order through the Website.<br>
4.2 To receive Payins from Users, the Company uses the requisites of crypto exchanges or cold wallet.<br>
4.2.1 Upon receipt of the Payin, the cryptocurrency is converted into Tether USDT at the current exchange rate.<br>
4.2.2 To send a Payout, the Company converts the required amount of cryptocurrency from its own Tether USDT reserves at the current exchange rate.<br>
4.3. Procedure for the providing of Services:<br>
4.3.1 By creating an Order on the Website, the User makes a request to receive the Service.<br>
4.3.2 In the Order, the User specify how much he wants to send or how much he wants to receive, and the Website automatically calculates the second amount, based on the current rate of the Company.<br>
4.3.3 The User undertakes to make the Payin in the same amount and in the same currency specified in the Order.<br>
4.3.4 The order is considered paid after the payment has been credited to the details of the Service and sold on the market on the cryptocurrency exchange<br>
4.3.5 After receiving the payment, the Service undertakes to make the Payment on the order in accordance with the rules specified in the instruction of the corresponding exchange direction.<br>
4.3.6 The obligations of the Company to fulfill the Order are considered fulfilled after the transfer of funds to the User's requisites, which can be confirmed by the corresponding transaction ID.<br>
<br>
5. Additional terms of service.<br>
5.1. If within 24 hours after the creation of the Order the User does not send the Payin to the specified requisites, then the Order's status will be changed to is transferred to the status Expired and Payin tracking is no longer performed on it.<br>
5.2. In case of receipt from the User of a Payin for an amount that differs from the amount in the Order:<br>
5.2.1 If the Payin amount differs from the Order amount by no more than 2%, the Company makes a proportional recalculation of the payout amount, but in accordance with the current cryptocurrency rates.<br>
5.2.2 If the amount of the Payin differs from the amount of the Order by more than 2%, the Company has the right to request photo/video materials confirming that the User belongs to the transaction.<br>
5.3 If technical work began on the crypto exchange after the User created the Order, due to which it became impossible to credit deposits and / or send withdrawals, the User undertakes to wait for the completion of the technical work.<br>
5.4 For technical reasons, the crypto exchange may reject the sent Payout and the funds will be returned to the account of the Company. The Company undertakes to resend the Payout at the request of the User.<br>
5.5 The order's status will be changed to Completed at the time of sending a request to the exchange to send the Payment to the User.<br>
<br>
6. Liability of the Parties.<br>
6.1 The OpenChange Company is liable to the User in an amount not exceeding the amount of funds transferred by the User.<br>
6.2 The OpenChange Company is not responsible for malfunctions, errors and failures in the operation of software and hardware that ensure the functioning of the Company's services that arose for reasons beyond the control of the Company, as well as the User's losses associated with this.<br>
6.3. The OpenChange Company is not responsible for the User's losses resulting from fraudulent actions of third parties.<br>
6.4. The User bears full responsibility for the accuracy of the information specified by him when filling out the Order. In the event that the User did not specify or incorrectly specified personal details or payment details, the OpenChange Company is not responsible for the User's losses incurred as a result of an error made by him.<br>
6.5. The user guarantees that he is not involved in:<br>
- money laundering operations;<br>
- receiving income from drug/weapon trafficking;<br>
- receiving income from criminal and/or terrorist activities;<br>
- income from trade with countries, trade with which is prohibited by international organizations;<br>
- income from any other illegal activity.<br>
6.6. The OpenChange Company is not responsible for possible losses of the User due to the commencement of technical work on the crypto exchange, deactivation of trading functions, crediting deposits and sending withdrawals.<br>
6.7. The OpenChange service is not responsible for the User's losses that may arise when the execution of the application is suspended due to the requirement of the exchange support to verify the User, during which it will be necessary to reverse convert all funds into the Original currency received from the User.<br>
6.8. The Parties are released from liability for full or partial failure to fulfill their obligations under the Agreement, if such was the result of force majeure circumstances that arose after the entry into force of the Agreement, as a result of extraordinary events that could not be foreseen and prevented by reasonable measures.<br>
<br>
7. Refunds.<br>
7.1 Refunds don't apply to Orders for which the User has already received a Payout.<br>
7.2 If the Company has received a Payin from the User and the User has decided to cancel the Service, then:<br>
7.2.1 If the funds for the Payout haven't yet been converted from Tether USDT (according to clause 4.2.2), then the Company converts the received amount of Tether USDT (according to clause 4.2.1) into the cryptocurrency that the User sent and sends the refund to the agreed details.<br>
7.2.2 If the funds for the Payout have already been converted from Tether USDT, then the Company first converts the funds for the Payout back to Tether USDT and then to the cryptocurrency that the User sent and sends the refund to the agreed details.<br>
7.2.3 In both cases, the Company withholds a fee of 30 USD and a fee for sending the return.<br>
7.3 If the User requests a refund on an Order, the Payin for which was less than 50% of the Order amount, the Company has the right to charge a fee of 1% (but not less than 50 USD) of the refund amount + a fee for sending the refund.<br>
<br>
8. Other terms.<br>
8.1 It is forbidden to use the OpenChange Company for fraudulent and illegal transactions.<br>
8.2 The administration of the OpenChange Company reserves the right to provide information about Payins and Payouts to law enforcement and other authorities in accordance with the AML policy of the Company.<br>
8.3 The User undertakes not to disrupt the operation of the OpenChange Company by interfering with its software or hardware.<br>
8.4 The OpenChange Company, in case of suspicious actions in the process of filling out an Order by the User, in order to avoid damage from hacker attacks, has the right to suspend the execution of such operations until the reasons for these actions are clarified.<br>
8.5 The Company Administration has the absolute right to refuse to provide services to any User without explanation.		</div>
</div>
</div>
                </div>
</section>
<?php echo $__env->make("parts/footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/antonrybalkin/Projects/cp/front_crypto/resources/views/tеrms.blade.php ENDPATH**/ ?>