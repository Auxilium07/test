<?php $__env->startSection('content'); ?>
    <div class="mb-4 shadow card">
        <div class="py-3 card-header d-flex">
            <h6 class="m-0 font-weight-bold text-primary">
                <?php echo e($review->user_id ? $review->user->full_name : $review->name); ?>

            </h6>
            <div class="ml-auto">
                <a href="<?php echo e(route('admin.reviews.index')); ?>" class="btn btn-primary">
                    <span class="text">Повертнутись до відгуків</span>
                </a>
            </div>
        </div>
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                <tr class="text-white bg-secondary">
                    <th>Поіне імʼя</th>
                    <th>Дата</th>
                </tr>
                </thead>
                <tbody>
                <tr>
                    <td>
                        <?php echo e($review->fullname); ?><br>
                        
                    </td>
                    <td><?php echo e($review->DateText); ?></td>
                </tr>
                </tbody>
                <thead>
                <tr class="text-white bg-secondary" >
                    <th colspan="5">Відгук</th>
                </tr>
                </thead>
                <tbody>
                <tr>
                    <td colspan="5"><?php echo e($review->content); ?></td>
                </tr>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/antonrybalkin/Projects/cp/resources/views/backend/reviews/show.blade.php ENDPATH**/ ?>