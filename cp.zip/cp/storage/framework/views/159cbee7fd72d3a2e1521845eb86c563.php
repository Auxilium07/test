<?php $__env->startSection('content'); ?>
    <div class="mb-4 shadow card">
        <div class="py-3 card-header d-flex">
            <h6 class="m-0 font-weight-bold text-primary">Заявка №<?php echo e($order->id); ?></h6>
            <div class="ml-auto d-flex">
                <a href="<?php echo e(route('admin.orders.edit', $order)); ?>" class="mr-4 btn btn-sm btn-primary">
                    <i class="fa fa-edit"></i>
                </a>
            </div>
        </div>
        <div class="d-flex">
            <div class="col-8">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <tbody>
                        <tr>
                            <th>Id</th>
                            <td><?php echo e($order->id); ?></td>
                            <th>Відповідальний</th>
                            <?php if($order->user!=null): ?>
                            <td><a href="<?php echo e(route('admin.users.show', $order->user_id)); ?>"><?php echo e($order->user->full_name); ?></a><br><?php echo e($order->user->phone); ?></td>
                            <?php else: ?>
                            <td>Не має відповідального</td>
                            <?php endif; ?>
                        </tr>

                        <tr>
                            <th>ПІБ</th>
                            <td>
                                <?php echo e($order->fullname()); ?>

                            </td>
                            <th>Email</th>
                            <td>
                                <?php echo e($order->email); ?>

                            </td>
                            <th>Телефон</th>
                            <td><?php echo e($order->phone); ?></td>
                        </tr>
                        <tr>
                            <th>Додано в</th>
                            <td><?php echo e($order->created_at->format('d-m-Y h:i a')); ?></td>
                            <th>Статус замовлення</th>
                            <td> 
                               <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split("changestatus",["order_id"=>$order->id,'current_status'=>$order->status]);

$__html = app('livewire')->mount($__name, $__params, 'lw-874408026-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                            </td>
                        </tr>
                        
                        </tbody>
                    </table>
                </div>
            </div>
           
        </div>
    </div>


    <div class="mb-4 shadow card">
        <div class="py-3 card-header">
            <h6 class="m-0 font-weight-bold text-primary">Коментарі</h6>
        </div>

        <div class="table-responsive">
            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('messages',["order_id"=>$order->id]);

$__html = app('livewire')->mount($__name, $__params, 'lw-874408026-1', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            
        </div>
    </div>
    <div class="mb-4 shadow card">
        <div class="py-3 card-header">
            <h6 class="m-0 font-weight-bold text-primary">Залишити коментар</h6>
        </div>

        <div class="table-responsive">
            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('form-message',["order_id"=>$order->id,'user_id'=>auth()->user()->id]);

$__html = app('livewire')->mount($__name, $__params, 'lw-874408026-2', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/antonrybalkin/Projects/cp/resources/views/backend/orders/show.blade.php ENDPATH**/ ?>