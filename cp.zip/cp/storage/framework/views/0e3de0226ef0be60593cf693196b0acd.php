<footer class="bg-white sticky-footer">
    <div class="container my-auto">
        <div class="my-auto text-center copyright">
            <span></span>
            <script>
                document.write(new Date().getFullYear())
            </script>
        </div>
    </div>
</footer>
<?php /**PATH /Users/antonrybalkin/Projects/cp/resources/views/partials/backend/footer.blade.php ENDPATH**/ ?>