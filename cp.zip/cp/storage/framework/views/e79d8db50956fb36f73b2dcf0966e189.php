<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-3">
            <div class="card">
                <div class="card-header">Налаштування</div>
                <ul class="list-group list-group-flush">
                    <?php $__currentLoopData = $setting_sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $setting_section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="list-group-item">
                            <a href="<?php echo e(route('admin.settings.index', ['section' => $setting_section])); ?>" class="nav-link">
                                <i class="fa fa-gear"></i>
                                <?php echo e($setting_section); ?>

                            </a>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
        <div class="col-9">
            <div class="card">
                <div class="card-header">Налаштування <?php echo e($section); ?></div>
                <div class="card-body">

                    <form action="<?php echo e(route('admin.settings.update', 1)); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PATCH'); ?>
                        <?php $__currentLoopData = $settings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $setting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="row">
                            <div class="col-12">
                                <div class="form-group">
                                    <label for="title"><?php echo e($setting->display_name); ?></label>
                                    <?php if($setting->type == 'text'): ?>
                                        <input type="text" name="value[<?php echo e($loop->index); ?>]" id="value" class="form-control" value="<?php echo e($setting->value); ?>">

                                    <?php elseif($setting->type == 'textarea'): ?>
                                        <textarea name="value[<?php echo e($loop->index); ?>]" id="value" class="form-control" cols="30" rows="10"><?php echo e($setting->value); ?></textarea>

                                    <?php elseif($setting->type == 'image'): ?>
                                        <input type="file" name="value[<?php echo e($loop->index); ?>]" id="value" class="form-control">
                                    <?php elseif($setting->type == 'radio'): ?>
                                        <fieldset class="form-check">
                                            <div class="form-check">
                                                <input type="radio" name="value[<?php echo e($loop->index); ?>]" id="value" <?php echo e($setting->value==1?"checked":""); ?> value="1" class="form-check-input">
                                                <label class="form-check-label" for="flexRadioDefault1">
                                                  Так
                                                </label>
                                              </div>
                                              <div class="form-check">
                                                <input type="radio" name="value[<?php echo e($loop->index); ?>]" id="value" <?php echo e($setting->value==0?"checked":""); ?> value="0"class="form-check-input">
                                                <label class="form-check-label" for="flexRadioDefault2">
                                                  Ні
                                                </label>
                                              </div>
                                        </fieldset>
                                    <?php elseif($setting->type == 'select'): ?>
                                        <select id="value" class="form-control">
                                            <option name="value[<?php echo e($loop->index); ?>]" value="<?php echo e(explode('|', $setting->details)); ?>">
                                                <?php echo e($setting->value); ?>

                                            </option>
                                        </select>

                                    <?php elseif($setting->type == 'checkbox'): ?>
                                        <input type="checkbox" name="value[<?php echo e($loop->index, 1); ?>]" id="value" class="styled"  <?php echo e($setting->value == 1 ? true : false); ?> >

                                    <?php elseif($setting->type == 'radio'): ?>
                                        <input type="radio" name="value[<?php echo e($loop->index, 1); ?>]" id="value" class="styled" value="<?php echo e($setting->value == 1 ? true : false); ?>">
                                    <?php elseif($setting->type='selection_page'): ?>
                                    <div class="form-group">
                                        <label for="page"><?php echo e($setting->details); ?></label>
                                        <select name="value[<?php echo e($loop->index); ?>]" id="<?php echo e($setting->key); ?>" class="form-control select2">
                                            <option value="null">Пусто</option>
                                            <?php echo e(logger($pages->pluck("id")->toArray())); ?>

                                            <?php $__empty_1 = true; $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <?php echo e(logger($setting->value)); ?>

                                           
                                                <option
                                                    value="<?php echo e($page->id); ?>" <?php echo e($setting->value==$page->id ? 'selected' : null); ?>>
                                                    <?php echo e($page->title); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <?php endif; ?>
                                        </select>
                                    </div>
                                    <?php endif; ?>
                                    <input type="hidden" name="key[<?php echo e($loop->index); ?>]" id="key" class="form-control" value="<?php echo e($setting->key); ?>" readonly>
                                    <input type="hidden" name="id[<?php echo e($loop->index); ?>]" id="key" class="form-control" value="<?php echo e($setting->id); ?>" readonly>
                                    <input type="hidden" name="ordering[<?php echo e($loop->index); ?>]" id="key" class="form-control" value="<?php echo e($setting->ordering); ?>" readonly>

                                    <?php $__errorArgs = ['value'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <div class="text-right">
                            <button type="submit" class="btn btn-primary">Зберегти</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/antonrybalkin/Projects/cp/resources/views/backend/settings/index.blade.php ENDPATH**/ ?>