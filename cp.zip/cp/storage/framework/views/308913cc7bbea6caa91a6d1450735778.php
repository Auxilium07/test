<?php $__env->startSection("styles"); ?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/datepicker/1.0.10/datepicker.min.css" integrity="sha512-YdYyWQf8AS4WSB0WWdc3FbQ3Ypdm0QCWD2k4hgfqbQbRCJBEgX0iAegkl2S1Evma5ImaVXLBeUkIlP6hQ1eYKQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<style>
    .form-group
    {
        position: relative;
    }
    input#phone + .validity {
  padding-right: 30px;
  width: 5px;
  height: 5px;
}
.validity{
    width: 5px;
    height: 5px;
}
input#phone:invalid+.validity:after,#phone + .validity:after {
  position: absolute; content: '✖';
  padding-left: 5px;
  color: #8b0000;
  top: 50%;
    transform: translateY(-50%);
}

input#phone:valid+.validity:after {
  position: absolute;
  content: '✓';
  padding-left: 5px;
  color: #009000;
  top: 50%;
    transform: translateY(-50%);
}

</style>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="mb-4 shadow card">
        <div class="py-3 card-header d-flex">
            <h6 class="m-0 font-weight-bold text-primary">
               Створення відгука на товар
            </h6>
            <div class="ml-auto">
                <a href="<?php echo e(route('admin.reviews.index')); ?>" class="btn btn-primary">
                    <span class="text">Повернутись до відгуків</span>
                </a>
            </div>
        </div>
        <form action="<?php echo e(route('admin.reviews.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('POST'); ?>
        <div class="table-responsive">
            <table class="table table-hover">
                <tbody>
                    <tr>
                        <th>Імʼя </th>
                        <td>
                            <input class="form-control" type="text" name="first_name" value="<?php echo e(old('first_name')); ?>">
                             
                            <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            
                            
                        </td>
                        <th>Прізвище </th>
                        <td>
                            <input class="form-control" type="text" name="last_name" value="<?php echo e(old('last_name')); ?>">
                             
                            <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            
                            
                        </td>
                    </tr>
                    <tr>
                        <th>По-батькові </th>
                        <td>
                            <input class="form-control"  type="text" name="middle_name" value="<?php echo e(old('middle_name')); ?>">
                             
                            <?php $__errorArgs = ['middle_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            
                            
                        </td>
                        <th>Дата відгука</th>
                        <td>
                            <input class="form-control" id="datepicker" type="text" name="date" value="<?php echo e(old('middle_name')); ?>">
                             
                            <?php $__errorArgs = ['middle_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            
                            
                        </td>

                    </tr>
          
                    <tr >
                        <th >Текст відгука</th>
                        <td>
                            <textarea class="form-control" id="content" type="text" name="content" ><?php echo e(old('content')); ?></textarea>
                            <?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </td>
                        <th >Збергти як чернетку?</th>
                        <td>
                            <input type="checkbox" name="status" <?php echo e(old("status")==true?'checked':''); ?>>
                            <?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </td>
                    </tr>
                    
                     
                      
                     

                </tbody>
            </table>
            <button type="submit" class="m-2 btn btn-primary">Створити</button>
        </div>
    </form>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/datepicker/1.0.10/datepicker.min.js" integrity="sha512-RCgrAvvoLpP7KVgTkTctrUdv7C6t7Un3p1iaoPr1++3pybCyCsCZZN7QEHMZTcJTmcJ7jzexTO+eFpHk4OCFAg==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script>
    $().ready(()=>{
      
    $( "#datepicker" ).datepicker();
 
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/antonrybalkin/Projects/cp/resources/views/backend/reviews/create.blade.php ENDPATH**/ ?>