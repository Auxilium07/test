	<?php echo $__env->make('parts/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      
    <article class="content">
                
    
    <section>
        <div class="container">
            <div id="mainLoading" class="loader-box">
                <div class="loader-wrapper">
        <div class="sk-fading-circle">
            <div class="sk-circle1 sk-circle"></div>
            <div class="sk-circle2 sk-circle"></div>
            <div class="sk-circle3 sk-circle"></div>
            <div class="sk-circle4 sk-circle"></div>
            <div class="sk-circle5 sk-circle"></div>
            <div class="sk-circle6 sk-circle"></div>
            <div class="sk-circle7 sk-circle"></div>
            <div class="sk-circle8 sk-circle"></div>
            <div class="sk-circle9 sk-circle"></div>
            <div class="sk-circle10 sk-circle"></div>
            <div class="sk-circle11 sk-circle"></div>
            <div class="sk-circle12 sk-circle"></div>
        </div>
    </div>			<form method="POST" action="/" class="main-change-box js-OrderForm" data-lang="/">
        <?php echo csrf_field(); ?>
                    <input type="hidden" name="sessid" id="sessid_3" value="907a9c50eefb3d2dd31dc13e130faf8c">
                    <div class="change-field long">
                        <div class="column">
                            <div class="title title-custom">Give<span>step 1</span>
                                <div class="system-icon search-custom">
                                    <input class="form-control" type="text" name="get">
                                    <p class="help-block help-block-error">Field must not be empty</p>
                                    <div class="img btn-search-custom"><img src="<?php echo e(asset("storage/images/icon-search.svg")); ?>" alt=""></div>
                                </div>
                            </div>
                            <fieldset class="choose-system" id="system-give">
                                <legend>Choose a system:</legend>
                                <?php if($currencies[0]): ?>
                                <?php $__currentLoopData = $currencies[0]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                               
                                                                <label>
                                        <input type="radio" name="system-give" data-codecurency="<?php echo e($item['id']); ?>" data-curency="COIN" data-send-precision="2" value="<?php echo e($item['id']); ?>">
                                        <span><?php echo e($item["name"]); ?> <?php echo e($item["name"]!=$item['symbol']?"(".strtoupper($item['symbol']).")":''); ?></span>
                                        <div class="img">
                                                                                        <img src="<?php echo e($item["image"]); ?> " class="table-icon" alt="<?php echo e($item["name"]); ?> <?php echo e($item["name"]!=$item['symbol']?"(".$item['symbol'].")":''); ?>" onerror="this.style.display='none';" >
                                                                                    </div>
                                    </label>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                                    
                                  <?php else: ?>
                                      <span><?php __("error")?></span>
                                  <?php endif; ?>
                                </fieldset>
                        </div>
                        <div class="column">
                            <div class="title title-custom">Get<span>step 2</span>
                                <div class="system-icon search-custom">
                                    <input class="form-control" type="text" name="get">
                                    <p class="help-block help-block-error">Field must not be empty</p>
                                    <div class="img btn-search-custom"><img src="<?php echo e(asset("storage/images/icon-search.svg")); ?>" alt=""></div>
                                </div>
                            </div>
                            <fieldset class="choose-system" id="system-get">
                                <legend>Choose a system:</legend>
                                <?php if($currencies[1]): ?>
                                <?php $__currentLoopData = $currencies[1]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                               
                                    <label id="<?php echo e($item['id']); ?>" class="hidden">
                                        <input type="radio" name="system-get" data-codecurency="<?php echo e($item['id']); ?>" data-curency="COIN" data-send-precision="2" value="<?php echo e($item['id']); ?>">
                                        <span><?php echo e($item["name"]); ?> <?php echo e($item["name"]!=$item['symbol']?"(".strtoupper($item['symbol']).")":''); ?></span>
                                        <div class="img">
                                            <img src="<?php echo e($item["image"]); ?> " class="table-icon" alt="<?php echo e($item["name"]); ?> <?php echo e($item["name"]!=$item['symbol']?"(".$item['symbol'].")":''); ?>" onerror="this.style.display='none';" style="display: none" >
                                        </div>
                                    </label>
                                    
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                                    
                                  <?php else: ?>
                                      <span><?php __("error")?></span>
                                  <?php endif; ?>
                                
                            </fieldset>
                        </div>
                    </div>
                    <div id="direction_field" class="change-field loader-box data">
                        <input name="make_order" type="hidden" value="Create order">
                        <input type="hidden" name="direction_code" value="">
                        <input type="hidden" id="min_send_amount" value="">
                        <input type="hidden" id="min_send_amount_direction" value="TO">
                        <input type="hidden" id="max_send_amount" value="">
                        <input type="hidden" id="max_send_amount_direction" value="TO">
                        <input type="hidden" id="receive_limit" value="">
                        <input type="hidden" id="receive_currency" value="">
                        <input type="hidden" name="currency_one" id="currency_one" value="">
                        <input type="hidden" name="currency_two" id="currency_two" value="">
    <!--					-->
                        <div class="title">
                            Data Input<span>step 3</span>
                        </div>
                        <div class="search-right-cuatom">
    
                            <div class="name-mute">
                                <span>Give</span>
                                <span class="pull-right"></span>
                            </div>
                            <div class="form-group system-icon">
                                <input class="form-control " type="text" id="field_amount" name="amount" value="" data-required="" data-validation="float" data-decimal="2" data-expr="" data-error="">
                                <span class="field_loader_calc"></span>
                                <p class="help-block help-block-error js-error ">
                                                                </p>
                                <div class="img"><img src="images/623bf9040d206.svg" alt="" style="display: none"></div>
                            </div>
                            <div class="name-mute">Get</div>
                            <div id="box_you_receive" class="form-group system-icon">
                                <input class="form-control " type="text" id="field_amount_to" name="amount_to" value="" data-validation="float" data-decimal="2" data-expr="" data-error="">
                                <span class="field_loader_calc"></span>
                                <p class="help-block help-block-error js-error ">
                                                                </p>
                                <div class="img"><img src="<?php echo e(asset("storage/images/66ead13d863d7.svg")); ?>" alt=""  style="display: none"></div>
                            </div>
                            <div id="reserve" data-name="Reserve" class="name-mute summ">
                                					</div>
                        </div>
    
                        <div class="inf-form" id="currency-info">
                            <div class="inf-form__btn"><span>Show additional information</span></div>
                            <div class="inf-form__main">
                                                                <p>
                                        <b>Rate</b>
                                        <span class="pull-right"></span>
                                    </p>
                                                                                            <p>
                                    <b>Reserve</b>
                                    <span class="pull-right"></span>
                                </p>
                                                                <p>
                                        <b>Min.sum</b>
                                        <span class="pull-right">
                                                                              </span>
                                    </p>
                                                                    <p>
                                        <b>Max.sum</b>
                                        <span class="pull-right">
                                           								    </span>
                                    </p>
                                                            </div>
                        </div>
    
                                                                                                    <div class="form-group ">
                                                            <input type="text" id="field_user_email" name="email" data-validate="" data-type="email" data-expr="" data-error="" value="" placeholder="E-Mail" class="form-control" required="required">
    
                                    
                                                            <p class="help-block help-block-error js-error ">
                                                        </p>
    
                        </div>
                        <div class="form-group ">
                            <input type="text" id="field_user_phone" name="phone" data-validate="" data-type="phone" data-expr="" data-error="" value="" placeholder="Phone" class="form-control" required="required">

    
                            <p class="help-block help-block-error js-error ">
                        </p>

</div>
                                                                <div class="form-group ">
                                                            <input type="text" id="field_account" name="wallet" value="" placeholder=" wallet" class="form-control" required="required">
    
                                    
                                                            <p class="help-block help-block-error js-error ">
                                                        </p>
    
                        </div>
                                                                <div class="form-group">
                            <label class="checkbox">
                                <input type="checkbox" required="required" name="i_agree" value="Y" class="js-Agreements">
                                <span>
                                    I agree to								<a href="/tеrms_of_service/" target="_blank" class="more u_hover"><u>User agreement</u></a>
                                </span>
                            </label>
                            <p class="help-block help-block-error "></p>
                        </div>
                        <div class="form-group">
                            <label class="checkbox">
                                <input type="checkbox" required="required" name="i_agree_aml" value="Y" class="js-Agreements">
                                <span>
                                    I agree to								<a href="/privacy_policy/" target="_blank" class="more u_hover"><u>AML Policy</u></a>
                                </span>
                            </label>
                            <p class="help-block help-block-error "></p>
                        </div>
    
                        <input name="make_order" type="hidden" value="Create order">
                        <button class="btn btn-default js_submit_btn" disabled="">Exchange now</button>
                                            
                                        <h3>Reviews</h3>
    <div class="reviews-slider">
                <div class="one-item">
                <p>Fast and legit, I recommend</p>
                <div class="review-info">
                                        <div class="when">09/05/2024 12:25:00 pm</div>
                                        <div class="who">Mohamad Alshawaf</div>
                </div>
            </div>
                    <div class="one-item">
                <p>Thanks team amazing work very quick and efficient</p>
                <div class="review-info">
                                        <div class="when">09/04/2024 12:57:00 am</div>
                                        <div class="who">J walker</div>
                </div>
            </div>
                    <div class="one-item">
                <p>Fast and easy</p>
                <div class="review-info">
                                        <div class="when">08/28/2024 11:29:00 am</div>
                                        <div class="who">Emmanuel</div>
                </div>
            </div>
                    <div class="one-item">
                <p>Thanks! Great service as always!</p>
                <div class="review-info">
                                        <div class="when">08/06/2024 04:16:26 pm</div>
                                        <div class="who">Key</div>
                </div>
            </div>
                    <div class="one-item">
                <p>Thanks bro, arrived in 5 mintues. usdt to skrill</p>
                <div class="review-info">
                                        <div class="when">07/29/2024 08:21:13 am</div>
                                        <div class="who">nico</div>
                </div>
            </div>
                    <div class="one-item">
                <p>Cool</p>
                <div class="review-info">
                                        <div class="when">07/19/2024 08:10:58 pm</div>
                                        <div class="who">Olexander</div>
                </div>
            </div>
                    <div class="one-item">
                <p>Trustworthy</p>
                <div class="review-info">
                                        <div class="when">07/19/2024 03:01:09 pm</div>
                                        <div class="who">Olexander</div>
                </div>
            </div>
                    <div class="one-item">
                <p>fast and easy</p>
                <div class="review-info">
                                        <div class="when">07/15/2024 12:45:17 am</div>
                                        <div class="who">Antonio</div>
                </div>
            </div>
                    <div class="one-item">
                <p>Fast and easy, take around 12 min for appears in my acc</p>
                <div class="review-info">
                                        <div class="when">07/14/2024 03:20:25 pm</div>
                                        <div class="who">Antony</div>
                </div>
            </div>
                    <div class="one-item">
                <p>Всё пришло удобно , быстро ,оператор  на связи, была ошибка с моей стороны все уладили , рекомендую</p>
                <div class="review-info">
                                        <div class="when">07/09/2024 12:14:15 pm</div>
                                        <div class="who">Дмитрий</div>
                </div>
            </div>
            </div>							</div>
            
                </form>
            </div>
        </div>
    </section>
    
    
        <script>
            lang_error = {
                min_send: "Minimum amount of sending is  ",
                max_send: "Maximum amount of sending is  ",
                max_receive: "Maximum amount of receive is  ",
                min_receive: "Minimum amount of receiving is  ",
                badvalue: "Incorrect value",
                bademail: "This field contains an invalid value. It must be a E-mail",
                badnumber: "The field must contain only digits"
            };
            lang = "/";
            $(document).ready(function() {
                        });
    
        var cards = {'FROM':{'field_number':'from_account','field_holder':'from_fio','cards':[]},'TO':{'field_number':'to_account','field_holder':'to_fio','cards':[]}};
        var cards_list 			= null;
        var cards_holders_list 	= {};
    
        lang_error = {
            min_send: "Minimum amount of sending is",
            max_send: "Maximum amount of sending is",
            max_receive: "Maximum amount of receive is  ",
            min_receive: "Minimum amount of receiving is  ",
            badvalue: "Incorrect value",
            bademail: "This field contains an invalid value. It must be a E-mail",
            badnumber: "The field must contain only digits"
        };
    
        for(var i in cards) {
            var direction_cards 		= cards[i];
            var field_number 			= direction_cards.field_number;
            var field_holder 			= direction_cards.field_holder;
            var direction_cards_list 	= Object.assign({}, direction_cards.cards);
    
            if(!direction_cards_list)
                continue;
    
            cards_list = [];
    
            for(var ii in direction_cards_list) {
                var card 	= direction_cards_list[ii];
                var number 	= card['NUMBER'];
    
                if(!number)
                    continue;
    
                cards_list.push(number);
            }
    
            var o2 = Object.assign({}, direction_cards_list);
    
            if(!!$('#field_' + field_number).length && cards_list.length > 0)
                createAutocomplete($('#field_' + field_number), $('#field_' + field_holder), cards_list, direction_cards_list);
        }
    
        function createAutocomplete($field_number, $field_holder, cards, holders) {
            $($field_number).autocomplete({
                minChars: 0,
                delimiter: /(,|;)\s*/, // Разделитель для нескольких запросов, символ или регулярное выражение
                maxHeight: 400,
                width: 428,
                zIndex: 9999,
                deferRequestBy: 0,
                onSelect: function(data) {
                    var value 	= data.value.toString().trim();
                    var card 	= holders['N_' + value];
                    var holder 	= (card ? card['HOLDER'] : '');
    
                    $(this).change();
                    $($field_holder).val(holder).prop('readonly', !!holder).toggleClass('has-success', !!holder);
                },
                lookup: cards
            }).change(function() {
                var value = $(this).val();
    
                if(!('N_' + value in holders))
                    $($field_holder).attr('readonly', false).prop('readonly', false).removeClass('has-success');
    
            }).parent().css('position', 'relative').append('<div class="search_icon"></div>');
        }
    </script>	
        <section>
            <div class="container">
                <script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.min.js" integrity="sha512-HGOnQO9+SP1V92SrtZfjqxxtLmVzqZpjFFekvzZVWoiASSQgSr4cw9Kqd2+l8Llp4Gm0G8GIFJ4ddwZilcdb8A==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
              
                <style>
                    @import url("https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick-theme.min.css");
                    @import url("https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.min.css");
                  
                </style>
    <div class="forum-icons">
        <a href="https://www.bestchange.com/openchange-exchanger.html" target="_blank" style="background-image:url(images/best-change.png)"><img src="images/best-change.png" alt=""></a>
        <a href="http://moneymakergroup.com/" target="_blank" style="background-image:url(images/mmg.png)"><img src="images/mmg.png" alt=""></a>
        <a href="http://talkgold.com/" target="_blank" style="background-image:url(images/talkgold.png)"><img src="images/talkgold.png" alt=""></a>
        <a href="http://moneytalkvillage.com/" target="_blank" style="background-image:url(images/mtv.png)"><img src="images/mtv.png" alt=""></a>
        <a href="http://bitcointalk.org/" target="_blank" style="background-image:url(images/bitcointalk.png)"><img src="images/bitcointalk.png" alt=""></a>
        <a href="http://bitcoinforum.com/" target="_blank" style="background-image:url(images/bitcoinforum.png)"><img src="images/bitcoinforum.png" alt=""></a>
        <a href="http://mmgp.ru/" target="_blank" style="background-image:url(images/mmgp.png)"><img src="images/mmgp.png" alt=""></a>
        <a href="http://rusmmg.ru/" target="_blank" style="background-image:url(images/rusmmg.png)"><img src="images/rusmmg.png" alt=""></a>
        <a href="http://forum.bits.media/" target="_blank" style="background-image:url(images/bits-media.png)"><img src="images/bits-media.png" alt=""></a>
        <a href="http://dreamteammoney.com/" target="_blank" style="background-image:url(images/ptm.png)"><img src="images/ptm.png" alt=""></a>
    
    </div>		</div>
        </section>
                                    </article>
                    
                            
<?php echo $__env->make('parts/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/antonrybalkin/Projects/cp/front_crypto/resources/views/index.blade.php ENDPATH**/ ?>