@section('styles')
<link rel="stylesheet" href="{{ asset('backend/vendor/datepicker/themes/classic.css') }}">
<link rel="stylesheet" href="{{ asset('backend/vendor/datepicker/themes/classic.date.css') }}">
<style>
    .picker__select--month,
    .picker__select--year {
        padding: 0 !important;
    }
</style>
@endsection
<div class="card-body">
    <form action="{{ $model }}" id="filter" method="GET">
        <div class="row align-items-center justify-content-center">
            <div class="col-2">
                <div class="form-group">
                    <label for="">Ключові слова в події</label>
                    <input type="text"
                           class="form-control"
                           name="keyword"
                           placeholder="Введіть для пошуку"
                           value="">
                </div>
            </div>
            <div class="col-2">
                <div class="form-group">
                    <label for="">Сортувати за</label>
                    <select name="orderBy" class="form-control">
                        <option value="">---</option>
                        <option value="asc" {{ old('orderBy', request()->input('orderBy') == 'asc' ? 'selected' : '') }}>за зростанням</option>
                        <option value="desc" {{ old('orderBy', request()->input('orderBy') == 'desc' ? 'selected' : '') }}>за спаданням</option>
                    </select>
                </div>
            </div>
            <div class="col-2">
                <div class="form-group">
                    <label for="">Вибірка за</label>
                    <select name="filterBy" class="form-control">
                        <option value="0">---</option>
                        <option value="1">Останній рік</option>
                        <option value="2">Останню чертверть</option>
                        <option value="3">Останній місяць</option>
                        <option value="4">Останній тиждень</option>
                        <option value="5">За вчорашній день</option>
                        <option value="6">Сьогодні</option>
                    </select>
                </div>
            </div>
            <div class="col-2">
                <div class="form-group">
                <div class="form-group">
                            <label for="start_date">Починаючи з</label>
                            <input class="form-control" id="start_date" type="text" name="start_date" value="">
                </div>
                </div>
            </div>
            <div class="col-2">
                <div class="form-group">
                <label for="expire_date">Закінчиючі по</label>
                <input class="form-control" id="expire_date" type="text" name="expire_date" value="">
                    </div>
                
            </div>
            <div class="col-2">
                <div class="form-group">
                    <label for="expire_date">Показувати по</label>
                    <select name="limitBy" class="form-control">
                        <option value="">---</option>
                        <option value="10" {{ old('limitBy', request()->input('limitBy') == '10' ? 'selected' : '') }}>10 шт</option>
                        <option value="20" {{ old('limitBy', request()->input('limitBy') == '20' ? 'selected' : '') }}>20 шт</option>
                        <option value="50" {{ old('limitBy', request()->input('limitBy') == '50' ? 'selected' : '') }}>50 шт</option>
                        <option value="100" {{ old('limitBy', request()->input('limitBy') == '100' ? 'selected' : '') }}>100 шт</option>
                    </select>
                </div>
            </div>
            
        </div>
        <div class="row col-12 ">
            <div class="form-group col-2">
                <select name="user_id" id="user_id" class="form-control select2">
                    <option  value="null">Пусто</option>
                    @forelse($users as $user)
                        <option
                            value="{{ $user->id }}" {{$user->id==request()->input('user_id')?"selected":''}}>
                            {{ $user->fullname }}
                        </option>
                    @empty
                    @endforelse
                </select>
                @error('user')<span class="text-danger">{{ $message }}</span>@enderror
            </div>
            <div class="col-1">
                <button type="submit" name="submit" class="btn btn-primary">Шукати</button>
            </div>
            <div class="col-1">
                <button type="button" onclick="document.querySelector('#filter').reset();$('#user_id').prop('selectedIndex',0);" class="btn btn-primary text-nowrap">Скинути налаштування</button>
            </div>
        </div>
    </form>
</div>
@section('scripts')
    <script src="{{ asset('backend/vendor/datepicker/picker.js') }}"></script>
    <script src="{{ asset('backend/vendor/datepicker/picker.date.js') }}"></script>
    <script>
        $(document).ready(function() {
    
            $("#start_date").pickadate({
                format: 'yyyy-mm-dd',
                selectMonths: true, // creates a dropdown to control month
                selectYears: true, // Creates a dropdown to control year
                clear: 'Clear',
                close: 'Ok',
                closeOnSelect: true, // Close upon selecting a date
            });
    
            var startdate = $('#start_date').pickadate('picker');
            var enddate = $('#expire_date').pickadate('picker');
    
            $("#start_date").change(function () {
                selected_ci_date = "";
                selected_ci_date = $('#start_date').val();
                if (selected_ci_date != null) {
                    var cidate = new Date(selected_ci_date);
                    min_codate = "";
                    min_codate = new Date();
                    min_codate.setDate(cidate.getDate() + 1);
                    enddate.set('min', min_codate);
    
                }
            });
    
            $('#expire_date').pickadate({
                format: 'yyyy-mm-dd',
                min: new Date(),
                selectMonths: true, // creates a dropdown to control month
                selectYears: true, // Creates a dropdown to control year
                clear: 'Clear',
                close: 'Ok',
                closeOnSelect: true, // Close upon selecting a date
            });
        });
    </script>
@endsection