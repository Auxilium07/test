<nav class="mb-4 bg-white shadow navbar navbar-expand navbar-light topbar static-top">

    <!-- Sidebar Toggle (Topbar) -->
    <button id="sidebarToggleTop" class="mr-3 btn btn-link d-md-none rounded-circle">
        <i class="fa fa-bars"></i>
    </button>

    <!-- Topbar Navbar -->
    <ul class="ml-auto navbar-nav">

        <!-- Nav Item - Alerts -->
        <li class="mx-1 nav-item dropdown no-arrow">
            <livewire:backend.notification-component />
        </li>

        <!-- Nav Item - Messages -->
        {{--
        <li class="mx-1 nav-item dropdown no-arrow">
            <a class="nav-link dropdown-toggle" href="#" id="messagesDropdown" role="button"
               data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <i class="fas fa-envelope fa-fw"></i>
                <!-- Counter - Messages -->
                <span class="badge badge-danger badge-counter">7</span>
            </a>
            <!-- Dropdown - Messages -->
            <div class="shadow dropdown-list dropdown-menu dropdown-menu-right animated--grow-in"
                 aria-labelledby="messagesDropdown">
                <h6 class="dropdown-header">
                    Message Center
                </h6>
                <a class="dropdown-item d-flex align-items-center" href="#">
                    <div class="mr-3 dropdown-list-image">
                        <img class="rounded-circle" src="{{ asset('backend/img/undraw_profile_1.svg') }}"
                             alt="...">
                        <div class="status-indicator bg-success"></div>
                    </div>
                    <div class="font-weight-bold">
                        <div class="text-truncate">Hi there! I am wondering if you can help me with a
                            problem I've been having.</div>
                        <div class="text-gray-500 small">Emily Fowler · 58m</div>
                    </div>
                </a>
                <a class="dropdown-item d-flex align-items-center" href="#">
                    <div class="mr-3 dropdown-list-image">
                        <img class="rounded-circle" src="{{ asset('backend/img/undraw_profile_2.svg') }}"
                             alt="...">
                        <div class="status-indicator"></div>
                    </div>
                    <div>
                        <div class="text-truncate">I have the photos that you ordered last month, how
                            would you like them sent to you?</div>
                        <div class="text-gray-500 small">Jae Chun · 1d</div>
                    </div>
                </a>
                <a class="dropdown-item d-flex align-items-center" href="#">
                    <div class="mr-3 dropdown-list-image">
                        <img class="rounded-circle" src="{{ asset('backend/img/undraw_profile_3.svg') }}"
                             alt="...">
                        <div class="status-indicator bg-warning"></div>
                    </div>
                    <div>
                        <div class="text-truncate">Last month's report looks great, I am very happy with
                            the progress so far, keep up the good work!</div>
                        <div class="text-gray-500 small">Morgan Alvarez · 2d</div>
                    </div>
                </a>
                <a class="dropdown-item d-flex align-items-center" href="#">
                    <div class="mr-3 dropdown-list-image">
                        <img class="rounded-circle" src="https://source.unsplash.com/Mv9hjnEUHR4/60x60"
                             alt="...">
                        <div class="status-indicator bg-success"></div>
                    </div>
                    <div>
                        <div class="text-truncate">Am I a good boy? The reason I ask is because someone
                            told me that people say this to all dogs, even if they aren't good...</div>
                        <div class="text-gray-500 small">Chicken the Dog · 2w</div>
                    </div>
                </a>
                <a class="text-center text-gray-500 dropdown-item small" href="#">Read More Messages</a>
            </div>
        </li>
        --}}

        <!-- Supervisor link -->

        @can('access_link')
            <li class="nav-item">
                <a class="nav-link text-dark" href="{{ route('admin.links.index') }}">
                    Посилання
                </a>
            </li>
        @endcan
        @can('access_supervisor')
            <li class="nav-item">
                <a class="nav-link text-dark" href="{{ route('admin.supervisors.index') }}">
                    Модератори
                </a>
            </li>
        @endcan
        @can('access_setting')
            <li class="nav-item">
                <a class="nav-link" href="{{ route('admin.settings.index') }}">
                    <span>
                        Налаштування
                    </span></a>
            </li>
        @endcan

        <div class="topbar-divider d-none d-sm-block"></div>

        <!-- Nav Item - User Information -->
        <li class="nav-item dropdown no-arrow">
            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button"
               data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                @auth()
                    <span class="mr-2 text-gray-600 d-none d-lg-inline small">{{ auth()->user()->first_name }}</span>
                @endauth
                @if(auth()->user()->user_image)
                    <img class="img-profile rounded-circle" src="{{ asset('storage/images/users/' . auth()->user()->user_image) }}"
                         alt="{{ auth()->user()->full_name }}">
                @else
                    <img class="img-profile rounded-circle" src="{{ asset('img/avatar.png') }}" alt="">
                @endif
            </a>
            <!-- Dropdown - User Information -->
            <div class="shadow dropdown-menu dropdown-menu-right animated--grow-in"
                 aria-labelledby="userDropdown">
                <a class="dropdown-item" href="{{ route('admin.account_setting') }}">
                    <i class="mr-2 text-gray-400 fas fa-user fa-sm fa-fw"></i>
                    Профіль
                </a>

                <div class="dropdown-divider"></div>

                @auth()
                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">
                    <i class="mr-2 text-gray-400 fas fa-sign-out-alt fa-sm fa-fw"></i>
                    Вийти
                </a>
                @endauth
            </div>
        </li>

    </ul>

</nav>
