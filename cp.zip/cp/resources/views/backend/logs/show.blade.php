@extends('layouts.admin')

@section('content')
<div class="mb-4 shadow card">
    <div class="py-3 card-header d-flex">
        <h6 class="m-0 font-weight-bold text-primary">
            Подій ID{{$logModel->id}}
        </h6>
        <div class="ml-auto d-flex">
            <a href="{{ route('admin.logs.index') }}" class="ml-auto btn btn-primary">Обратно</a>
        </div>

    </div>

    <div class="table-responsive">
        <table class="table table-hover">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Користувач</th>
                    <th>Створено</th>
                    <th>Що зроблено</th>
                </tr>
            </thead>
            <tbody>
                @if($logModel!=null&&$logModel->count()>0)
                <tr>
                    <td>{{$logModel->id}}</td>

                    <td>

                        @if($logModel->user!=null)
                        <a href="{{ route('admin.users.show', $logModel->user->id) }}">
                            {{ $logModel->user->full_name }}
                        </a><br>
                        <strong>( {{ $logModel->user->username }} )</strong>
                        @else
                        <span>Користувач не знайден</span>
                        @endif
                    </td>
                    <td>{{ $logModel->created_at ? $logModel->created_at->format('Y-m-d:H:i:s') : '' }}</td>
                    <td>
                        <table>
                            @if($logModel->action!=null)
                            @foreach(json_decode($logModel->action) as $keyItem=>$keyVal)

                            @if($keyItem=="name")
                            <tr>
                                <td>{{$keyVal}}</td>
                            </tr>
                            @endif
                            @if($keyItem=="detail")
                            <tr>
                                <td>{{$keyVal}}</td>
                            </tr>
                            @endif
                            @if($keyItem=="before")
                            <tr>
                                <th>Було</th>

                            </tr>

                            @foreach(json_decode($keyVal) as $key=>$val)
                            <tr> <td>{{$val}}</td></tr>
                            @endforeach

                            @endif
                            @if($keyItem=="after")
                            <tr>
                                <th>Стало</th>

                            </tr>

                            @foreach(json_decode($keyVal) as $key=>$val)
                            <tr> <td>{{$val}}</td></tr>
                            @endforeach

                            @endif



                            @endforeach
                            @endif
                        </table>
                    </td>
                </tr>
                @endif
            </tbody>
            <tfoot>
                @if($logModel==null)
                <tr>
                    <td colspan="4">
                        <div class="float-right">
                            Помилка
                        </div>
                    </td>
                </tr>
                @endif
            </tfoot>
        </table>
    </div>
</div>
@endsection
