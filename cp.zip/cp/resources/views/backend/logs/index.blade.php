@extends('layouts.admin')

@section('content')
    <div class="mb-4 shadow card">
        <div class="py-3 card-header d-flex">
            <h6 class="m-0 font-weight-bold text-primary">
                Журнал подій
            </h6>
            <div class="ml-auto d-flex">
            </div>

        </div>

        @include('partials.backend.filter-date', ['model' => route('admin.logs.index')])
       
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                <tr>
                    <th>ID</th>
                    <th>Користувач</th>
                    <th>Створено</th>
                    <th>Що зроблено</th>
                </tr>
                </thead>
                <tbody>
                @forelse($logs as $log)
                    <tr>
                        <td><a href="{{ route('admin.logs.show', $log->id) }}">
                            {{ $log->id }}
                        </a></td>
                        <td>
                            @if($log->user!=null)
                            <a href="{{ route('admin.users.show', $log->user->id) }}">
                                {{ $log->user->full_name }}
                            </a><br>
                            <strong>( {{ $log->user->username }} )</strong>
                            @else
                                <span>Користувач не знайден</span>
                            @endif
                        </td>
                        <td>{{ $log->created_at ? $log->created_at->format('Y-m-d:H:i:s') : '' }}</td>
                        <td>
                            <table>
                                @if($log->action!=null&&json_decode($log->action)!=null)
                                @foreach(json_decode($log->action) as $keyItem=>$keyVal)
    
                                @if($keyItem=="name")
                                <tr>
                                    <td>{{$keyVal}}</td>
                                </tr>
                                @endif
                                @if($keyItem=="detail")
                                <tr>
                                    <td>{{$keyVal}}</td>
                                </tr>
                                @endif
                                @if($keyItem=="before")
                                <tr>
                                    <th>Було</th>
    
                                </tr>
    
                                @foreach(json_decode($keyVal) as $key=>$val)
                                @if( $loop->first or $loop->iteration  <= 3 )
                            <tr> <td>{{$val}}</td></tr>
                            @endif
                            @if($loop->iteration  == 3 )
                            <tr><td><a href="{{ route('admin.logs.show', $log->id) }}">
                                Перейдіть в цей лог щоб побачіти більше
                            </a></td></tr>
                            @endif
                            
                                @endforeach
    
                                @endif
                                @if($keyItem=="after")
                                <tr>
                                    <th>Стало</th>
    
                                </tr>
    
                                @foreach(json_decode($keyVal) as $key=>$val)
                                @if( $loop->first or $loop->iteration  <= 3 )
                            <tr> <td>{{$val}}</td></tr>
                            @endif
                            @if($loop->iteration  == 3 )
                            <tr><td><a href="{{ route('admin.logs.show', $log->id) }}">
                                Перейдіть в цей лог щоб побачіти більше
                            </a></td></tr>
                            @endif
                                @endforeach
    
                                @endif
    
    
    
                                @endforeach
                                @endif
                            </table>
                        </td>
                        
                    </tr>
                @empty
                    <tr>
                        <td class="text-center" colspan="3">Записів не знайдено.</td>
                    </tr>
                @endforelse
                </tbody>
                <tfoot>
                
                <tr>
                    <td colspan="4">
                        <div class="float-right">
                            {!! $logs->appends(request()->all())->links() !!}
                        </div>
                    </td>
                </tr>
                
                </tfoot>
            </table>
        </div>
    </div>
@endsection
