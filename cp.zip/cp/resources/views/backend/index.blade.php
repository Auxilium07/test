@extends('layouts.admin')
@section('content')
    <!-- Page Heading -->
    <div class="mb-4 d-sm-flex align-items-center justify-content-between">
        <h1 class="mb-0 text-gray-800 h3">Адмін панель</h1>
        <p class="ml-auto col-6">Оберіть розділ</p>
    </div>


    

@endsection


