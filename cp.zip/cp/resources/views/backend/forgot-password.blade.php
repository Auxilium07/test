@extends('layouts.admin-auth')

@section('content')
    <div class="row justify-content-center">
        <div class="col-xl-10 col-lg-12 col-md-9">
            <div class="my-5 border-0 shadow-lg card o-hidden">
                <div class="p-0 card-body">
                    <!-- Nested Row within Card Body -->
                    <div class="row">
                        <div class="col-lg-6 d-none d-lg-block bg-password-image"></div>
                        <div class="col-lg-6">
                            <div class="p-5">
                                <div class="text-center">
                                    <h1 class="mb-2 text-gray-900 h4">Забули пароль?</h1>
                                    <p class="mb-4">Ми це розуміємо, всяке трапляється. Просто введіть свою електронну адресу нижче
                                        і ми надішлемо вам посилання для скидання пароля!</p>
                                </div>
                                <form class="user" action="{{ route('admin.forgot_password') }}" method="POST">
                                    @csrf
                                    <div class="form-group">
                                        <input type="email" name="email" value="{{ old('email') }}"
                                               class="form-control form-control-user"
                                               placeholder="Enter Email Address...">
                                        @error('email')<span class="text-danger">{{ $message }}</span>@enderror
                                    </div>
                                    <button type="submit" class="btn btn-primary btn-user btn-block">
                                        Скинути пароль
                                    </button>
                                </form>
                                <hr>
                                <div class="text-center">
                                    <a class="small" href="{{ route('admin.login') }}">
                                        Вже є аккаунт? Вхід!
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
