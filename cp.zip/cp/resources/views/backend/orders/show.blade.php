@extends('layouts.admin')
@section('content')
    <div class="mb-4 shadow card">
        <div class="py-3 card-header d-flex">
            <h6 class="m-0 font-weight-bold text-primary">Заявка №{{ $order->id }}</h6>
            <div class="ml-auto d-flex">
                <a href="{{ route('admin.orders.edit', $order) }}" class="mr-4 btn btn-sm btn-primary">
                    <i class="fa fa-edit"></i>
                </a>
            </div>
        </div>
        <div class="d-flex">
            <div class="col-8">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <tbody>
                        <tr>
                            <th>Id</th>
                            <td>{{ $order->id }}</td>
                            <th>Відповідальний</th>
                            @if($order->user!=null)
                            <td><a href="{{ route('admin.users.show', $order->user_id) }}">{{ $order->user->full_name }}</a><br>{{ $order->user->phone }}</td>
                            @else
                            <td>Не має відповідального</td>
                            @endif
                        </tr>

                        <tr>
                            <th>ПІБ</th>
                            <td>
                                {{$order->fullname()}}
                            </td>
                            <th>Email</th>
                            <td>
                                {{$order->email}}
                            </td>
                            <th>Телефон</th>
                            <td>{{ $order->phone }}</td>
                        </tr>
                        <tr>
                            <th>Додано в</th>
                            <td>{{ $order->created_at->format('d-m-Y h:i a') }}</td>
                            <th>Статус замовлення</th>
                            <td> 
                               @livewire("changestatus",["order_id"=>$order->id,'current_status'=>$order->status])
                            </td>
                        </tr>
                        
                        </tbody>
                    </table>
                </div>
            </div>
           
        </div>
    </div>


    <div class="mb-4 shadow card">
        <div class="py-3 card-header">
            <h6 class="m-0 font-weight-bold text-primary">Коментарі</h6>
        </div>

        <div class="table-responsive">
            @livewire('messages',["order_id"=>$order->id])
            
        </div>
    </div>
    <div class="mb-4 shadow card">
        <div class="py-3 card-header">
            <h6 class="m-0 font-weight-bold text-primary">Залишити коментар</h6>
        </div>

        <div class="table-responsive">
            @livewire('form-message',["order_id"=>$order->id,'user_id'=>auth()->user()->id])
        </div>
    </div>
@endsection
