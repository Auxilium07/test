@extends('layouts.admin')

@section('content')
<div class="mb-4 shadow card">
    <div class="py-3 card-header d-flex">
        <h6 class="m-0 font-weight-bold text-primary">Нова зявка </h6>
        <div class="ml-auto d-flex">
            <a href="{{ route('admin.orders.index') }}" class="mr-4 btn btn-sm btn-primary">
                <span>Повернутись до списку</span>
            </a>
        </div>
    </div>
    <form  method="POST" action="{{route('admin.orders.store')}}">
        @method('POST')
        @csrf
        <div class="col">
            <div class="table-responsive">
                <table class="table table-hover">
                    <tbody>
                    <tr class="my-4">

                        <th>Відповідальний</th>
                        <td>
                           
                          
                            <div class="d-flex flex-column">
                            <select class="form-control w-100"  name="user_id" style="outline-style: none;">
                                <option value=""> Оберіть відповідального </option>
                                @foreach($users as $user)
                                <option value="{{ $user->id }}" {{old('user_id')==$user->id?'selected':''}} >{{ $user->username }}</option>
                                @endforeach
                            </select>
                            
                            @error('user_id')
                                <span class="text-gray-500 display-6" >{{ $message }}</span>
                            @enderror</div>
                           
                        </td>
                       
                    </tr>
                    <tr>
                        <th>Прізвище</th>
                        <td>
                            <div class="mb-3 input-group">
                                <input type="text" class="form-control w-100"  name='lastname' value="{{ old('lastname')}}" placeholder="Введіть прізвище"  >
                                @error('lastname')
                                <span class="text-gray-500 display-6 " >{{ $message }}</span>
                            @enderror
                            </div>
                        </td>
                        <th>Імʼя</th>
                        <td>
                            <div class="mb-3 input-group d-flex flex-column">
                                
                                <input type="text" class="form-control w-100"  name='firstname' value="{{ old('firstname')}}" placeholder="Введіть імʼя" >
                                @error('firstname')
                                <span class="text-gray-500 display-6 " >{{ $message }}</span>
                            @enderror
                            </div>
                        </td>
                        <tr><th>По-батькові</th>
                        <td>
                            <div class="mb-3 input-group d-flex flex-column">
                                
                                <input type="text" class="form-control w-100"  name='middlename' value="{{old('middlename')}}" placeholder="Введіть по-батькові" >
                                @error('middlename')
                                <span class="text-gray-500 display-6 " >{{ $message }}</span>
                            @enderror
                            </div>
                        </td>
                        <th>Особистий рахунок клієнта</th>
                        <td>
                            <div class="mb-3 input-group d-flex flex-column">
                                
                                <input type="text" class="form-control w-100"  name='wallet' value="{{old('wallet')}}" placeholder="Особистий рахунок клієнта" >
                                @error('wallet')
                                <span class="text-gray-500 display-6 " >{{ $message }}</span>
                            @enderror
                            </div>
                        </td>
                    </tr>
                    </tr>
                   <tr  class="my-4">
                    <th>Телефон</th>
                    <td>
                        <div class="mb-3 input-group d-flex flex-column">
                            <input type="text" class="form-control w-100"  name='phone' value="{{old('phone')}}" placeholder="Номер телефону" aria-label="phone" >
                           @error('phone')
                            <span class="text-gray-500 display-6 " >{{ $message }}</span>
                        @enderror
                        </div>
                    </td>
                    <th>Email</th>
                    <td>
                        <div class="mb-3 input-group d-flex flex-column">
                            
                            <input type="email" class="form-control w-100"  name='email' value="{{old('email')}}" placeholder="Email" aria-label="Email" >
                            @error('email')
                            <span class="text-gray-500 display-6 " >{{ $message}}</span>
                        @enderror
                        </div>
                    </td>
                   </tr>

                   <tr  class="my-4">
                    <th>Сумма з</th>
                    <td>
                        <div class="mb-3 input-group d-flex flex-column">
                            <input type="number" class="form-control w-100"  name='amount' value="{{old('amount')}}" placeholder="Введіть число"  >
                          </div>
                          @error('amount')
                            <span class="text-gray-500 display-6 " >{{ $message }}</span>
                        @enderror
                    </td>
                    <th>Сумма до</th>
                    <td>
                        <div class="mb-3 input-group d-flex flex-column">
                            
                            <input type="number" class="form-control w-100"  name='amount_to' value="{{old('amount_to')}}" placeholder="Введіть число" >
                            @error('amount_to')
                            <span class="text-gray-500 display-6 " >{{ $message}}</span>
                        @enderror
                        </div>
                    </td>
                   </tr>
                   <tr  class="my-4">
                    <th>Валюта з</th>
                    <td>
                        <div class="mb-3 input-group d-flex flex-column">
                            <input type="text" class="form-control w-100"  name='currency_one' value="{{old('currency_one')}}" placeholder="Введіть число"  >
                            @error('currency_one')
                            <span class="text-gray-500 display-6 " >{{ $message }}</span>
                        @enderror
                        </div>
                    </td>
                    <th>Валюта до</th>
                    <td>
                        <div class="mb-3 input-group d-flex flex-column">
                            
                            <input type="text" class="form-control w-100"  name='currency_two' value="{{old('currency_two')}}" placeholder="Введіть число" >
                           @error('currency_two')
                            <span class="text-gray-500 display-6 " >{{ $message}}</span>
                        @enderror
                        </div>
                    </td>
                   </tr>
                    <tr  class="my-4">

                        <th>Статус заявки</th>
                        <td><div class="form-row align-items-center">
                            <label class="sr-only" for="inlineFormInputGroupUsername">Статус заявки</label>
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <div class="input-group-text">Статус заявки</div>
                                </div>
                                <div class="d-flex flex-column">
                                <select class="form-control w-100"  name="status" style="outline-style: none;">
                                    <option disabled value=""> Оберіть опцію </option>
                                    @foreach($orderStatusArray as $key => $value)
                                    <option value="{{ $key }}" {{old('status')==$key?"selected":null}}>{{ $value }}</option>
                                    @endforeach
                                </select>
                                @error('tatus')
                                <span class="text-gray-500 display-6 " >{{ $message }}</span>
                            @enderror</div>
                            </div>
                        </div></td>
                    </tr>
                    <tr>
                       <td> <button class="btn btn-primary">Зберегти</button></td>
                    </tr>
                    </tbody>
                
                </table>
            </div>
        </div>
        
    </form>
</div>

@livewireScripts
@endsection
