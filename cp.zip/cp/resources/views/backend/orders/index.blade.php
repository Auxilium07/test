@extends('layouts.admin')

@section('content')
    <div class="mb-4 shadow card">
        <div class="py-3 card-header d-flex">
            <h6 class="m-0 font-weight-bold text-primary">
                Заявки
            </h6>
            <div class="ml-auto">
                <div class="ml-auto">
                    @can('create_order')
                        <a href="{{ route('admin.orders.create') }}" class="btn btn-primary">
                        <span class="icon text-white-50">
                            <i class="fa fa-plus"></i>
                        </span>
                            <span class="text">Нова заявка</span>
                        </a>
                    @endcan
                </div>
            </div>
        </div>

        @include('backend.orders.filter')

        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                <tr>
                    <th>ID</th>
                    <th>Відповідальний</th>
                    <th>ПІБ замовника</th>
                    <th>Email</th>
                    <th>Телефон</th>
                    <th>Статус</th>
                    <th>Сумма</th>
                    <th>З якої валюти</th>
                    <th>В яку валюту</th>
                    <th>Дії</th>
                </tr>
                </thead>
                <tbody>
                @forelse($orders as $order)
                    <tr>
                        <td class="gap-2 d-flex align-content-center">
                            {{-- <input class="m-0" type="checkbox" name="order" value="{{$order->id}}"> --}}
                            <a href="{{ route('admin.orders.show', $order) }}">
                                {{ $order->id }}
                            </a>
                        </td>
                        <td>
                            @if($order->user!=null)
                            {{ $order->user->full_name }}
                            @else
                            Не призначено
                            @endif</td>
                            <td>{{ $order->lastname.' '.$order->firstname.' '.$order->middlename }}</td>
                            <td>{{ $order->email }}</td>
                            <td>{{ $order->phone }}</td>
                            <td>{{ $order->statusText() }}</td>
                        <td>{{ $order->amount_to }}</td>
                        <td>{{$order->currency_one}}</td>
                        <td>{{$order->currency_two}}</td>
                        <td>
                            @can('edit_order')
                            <a href="{{ route('admin.orders.edit', $order) }}" class="btn btn-sm btn-primary">
                                <i class="fa fa-edit"></i>
                            </a>
                            @endcan
                            @can('delete_order')
                            <a href="javascript:void(0);"
                               onclick="if (confirm('Are you sure to delete this record?'))
                                   {document.getElementById('delete-order-{{ $order->id }}').submit();} else {return false;}"
                               class="btn btn-sm btn-danger">
                                <i class="fa fa-trash"></i>
                            </a>
                            <form action="{{ route('admin.orders.destroy', $order) }}"
                                  method="POST"
                                  id="delete-order-{{ $order->id }}" class="d-none">
                                @csrf
                                @method('DELETE')
                            </form>
                            @endcan
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td class="text-center" colspan="10">Заявок в базі не знайдено.</td>
                    </tr>
                @endforelse
                </tbody>
                <tfoot>
                <tr>
                    <td colspan="10">
                        <div class="float-right">
                            {!! $orders->appends(request()->all())->links() !!}
                        </div>
                    </td>
                </tr>
                </tfoot>
            </table>
        </div>
    </div>
@endsection
