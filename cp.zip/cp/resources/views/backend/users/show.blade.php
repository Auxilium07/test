@extends('layouts.admin')

@section('content')
    <div class="mb-4 shadow card">
        
        <div class="py-3 card-header">
            Сторінка користувача
           
            
            <div class="mt-1 d-flex align-items-center">
                @if($user->user_image)
                <img class="mr-5" src="{{ asset('storage/images/users/' . $user->user_image) }}" alt="" style="width: 70px;">
            @else
                <img class="mr-5" src="{{ asset('img/avatar.png') }}" alt="{{ $user->full_name }}" style="width: 70px;">
            @endif
                {{ $user->full_name }}
            <div class="ml-auto">
                <a href="{{ route('admin.users.index') }}" class="btn btn-primary">
                    <span class="text">До користувачів</span>
                </a>
            </div>
            </div>
        </div>
        <div class="table-responsive">
            <table class="table table-hover">
                <tbody>
                <tr>
                    <th>ID</th>
                    <td>{{ $user->id }}</td>
                    <th>Імʼя</th>
                    <td>{{ $user->first_name }}</td>
                    <th>Прізвище</th>
                    <td>{{ $user->last_name }}</td>
                </tr>
                <tr>
                    <th>Email</th>
                    <td>{{ $user->email==null?"-":$user->email }}</td>
                    <th>Username</th>
                    <td>{{ $user->username }}</td>
                    <td>Номер телефона</td>
                    <td>{{ $user->phone==null?"-":$user->phone }}</td>
                </tr>
                <tr>
                    <th>Статус</th>
                    <td>{{ $user->status }}</td>
                    <td>Email підтвреджений</td>
                    <td>{{ $user->email_verified_at ? $user->email_verified_at->format('Y-m-d') : "-" }}</td>
                    <td>Зареєстрований</td>
                    <td>{{ $user->created_at ? $user->created_at->format('Y-m-d') : "-" }}</td>
                </tr>
                </tbody>
            </table>
        </div>
    </div>
@endsection
