@extends('layouts.admin')

@section('content')
    <div class="mb-4 shadow card">
        <div class="py-3 card-header d-flex">
            <h6 class="m-0 font-weight-bold text-primary">
                Додати користувача
            </h6>
            <div class="ml-auto">
                <a href="{{ route('admin.users.index') }}" class="btn btn-primary">
                    <span class="icon text-white-50">
                        <i class="fa fa-home"></i>
                    </span>
                    <span class="text">До користувачів</span>
                </a>
            </div>
        </div>
        <div class="card-body">
            <form method="POST" action="{{ route('admin.users.store') }}" enctype="multipart/form-data">
                @csrf
                <div class="row">
                    <div class="col-6">
                        <div class="form-group">
                            <label for="first_name" class="text-small ">Імʼя</label>
                            <input id="first_name" type="text" class="form-control form-control-lg" name="first_name"
                                   value="{{ old('first_name') }}" placeholder="Імʼя">
                            @error('first_name')<span class="text-danger">{{ $message }}</span>@enderror
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="form-group">
                            <label for="last_name" class="text-small ">Прізвище</label>
                            <input id="last_name" type="text" class="form-control form-control-lg" name="last_name"
                                   value="{{ old('last_name') }}" placeholder="Прізвище">
                            @error('last_name')<span class="text-danger">{{ $message }}</span>@enderror
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-6">
                        <div class="form-group">
                            <label for="username" class="text-small ">{{ __('Username') }}</label>
                            <input id="username" type="text" class="form-control form-control-lg" name="username"
                                   value="{{ old('username') }}" placeholder="Username">
                            @error('username')<span class="text-danger">{{ $message }}</span>@enderror
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="form-group">
                            <label for="email" class="text-small ">Електронна адреса</label>
                            <input id="email" type="email" class="form-control form-control-lg" name="email"
                                   placeholder="Електронна адреса">
                            @error('email')<span class="text-danger">{{ $message }}</span>@enderror
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-6">
                        <div class="form-group">
                            <label for="phone" class="text-small ">Номер телефона</label>
                            <input id="phone" type="text" class="form-control form-control-lg" name="phone"
                                   placeholder="Номер телефона">
                            @error('phone')<span class="text-danger">{{ $message }}</span>@enderror
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="form-group">
                            <label for="status">Статус</label>
                            <select name="status" id="status" class="form-control">
                                <option value="">-- Оберіть стан юзера --</option>
                                <option value="1" {{ old('status') == "1" ? 'selected' : null }}>Так</option>
                                <option value="0" {{ old('status') == "0" ? 'selected' : null }}>Ні</option>
                            </select>
                            @error('status')<span class="text-danger">{{ $message }}</span>@enderror
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-6">
                        <div class="form-group">
                            <label for="password" class="text-small ">Новий пароль</label>
                            <input id="password" type="password" class="form-control form-control-lg"
                                   name="password"
                                   placeholder="Введіть пароль">
                            @error('password')<span class="text-danger">{{ $message }}</span>@enderror
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="form-group">
                            <label for="password-confirm"
                                   class="text-small ">Підтвердження паролю</label>
                            <input id="password-confirm" type="password" class="form-control form-control-lg"
                                   name="password_confirmation" placeholder="Підтвердження паролю">
                            @error('password-confirm')<span class="text-danger">{{ $message }}</span>@enderror
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">
                        <label for="user_image">Аватар</label>
                        <br>
                        <div class="form-group">
                            <input type="file" name="user_image">
                        </div>
                        @error('user_image')<span class="text-danger">{{ $message }}</span>@enderror
                    </div>
                </div>
                <div class="form-group">
                    <button type="submit" class="btn btn-primary">
                        Зареєструватись
                    </button>
                </div>
            </form>
        </div>
    </div>
@endsection
