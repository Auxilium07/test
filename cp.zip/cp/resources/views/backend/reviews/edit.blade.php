@extends('layouts.admin')
@section("styles")
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/datepicker/1.0.10/datepicker.min.css" integrity="sha512-YdYyWQf8AS4WSB0WWdc3FbQ3Ypdm0QCWD2k4hgfqbQbRCJBEgX0iAegkl2S1Evma5ImaVXLBeUkIlP6hQ1eYKQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
@endsection
@section('content')
    <div class="mb-4 shadow card">
        <div class="py-3 card-header d-flex">
            <h6 class="m-0 font-weight-bold text-primary">
                Редагувати відгук : ({{ $review->id}})
            </h6>
            <div class="ml-auto">
                <a href="{{ route('admin.reviews.index') }}" class="btn btn-primary">
                    <span class="icon text-white-50">
                    </span>
                    <span class="text">Повернутись до відгків</span>
                </a>
            </div>
        </div>
        <div class="card-body">
            <form action="{{ route('admin.reviews.update', $review) }}" method="POST">
                @csrf
                @method('PATCH')
               
       
        
        <div class="table-responsive">
            <table class="table table-hover">
                <tbody>
                    <tr>
                        <th>Імʼя </th>
                        <td>
                            <input class="form-control" type="text" name="first_name" value="{{ $review->first_name }}">
                             
                            @error('first_name')<span class="text-danger">{{ $message }}</span>@enderror
                            
                            
                        </td>
                        <th>Прізвище </th>
                        <td>
                            <input class="form-control" type="text" name="last_name" value="{{ $review->last_name }}">
                             
                            @error('last_name')<span class="text-danger">{{ $message }}</span>@enderror
                            
                            
                        </td>
                    </tr>
                    <tr>
                        <th>По-батькові </th>
                        <td>
                            <input class="form-control"  type="text" name="middle_name" value="{{ $review->middle_name }}">
                             
                            @error('middle_name')<span class="text-danger">{{ $message }}</span>@enderror
                            
                            
                        </td>
                        <th>Дата відгука</th>
                        <td>
                            <input class="form-control" id="datepicker" type="text" name="date" value="{{$review->DateText}}">
                             
                            @error('middle_name')<span class="text-danger">{{ $message }}</span>@enderror
                            
                            
                        </td>

                    </tr>
          
                    <tr >
                        <th >Текст відгука</th>
                        <td>
                            <textarea class="form-control" id="content" type="text" name="content" >{{ $review->content }}</textarea>
                            @error('content')<span class="text-danger">{{ $message }}</span>@enderror
                        </td>
                        <th >Збергти як чернетку?</th>
                        <td>
                            <input type="checkbox" name="status" {{$review->status==true?'checked':''}}>
                            @error('content')<span class="text-danger">{{ $message }}</span>@enderror
                        </td>
                    </tr>
                    
                     
                      
                     

                </tbody>
            </table>
            <div class="pt-4 form-group">
                <button class="btn btn-primary" type="submit" name="submit">Оновити</button>
            </div>
        </div>
    
                
            </form>
        </div>
    </div>
@endsection
@section('scripts')
<script src="https://cdnjs.cloudflare.com/ajax/libs/datepicker/1.0.10/datepicker.min.js" integrity="sha512-RCgrAvvoLpP7KVgTkTctrUdv7C6t7Un3p1iaoPr1++3pybCyCsCZZN7QEHMZTcJTmcJ7jzexTO+eFpHk4OCFAg==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script>
    $().ready(()=>{
      
    $( "#datepicker" ).datepicker();
 
    })
</script>
@endsection