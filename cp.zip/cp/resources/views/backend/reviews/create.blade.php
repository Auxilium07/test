@extends('layouts.admin')

@section("styles")
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/datepicker/1.0.10/datepicker.min.css" integrity="sha512-YdYyWQf8AS4WSB0WWdc3FbQ3Ypdm0QCWD2k4hgfqbQbRCJBEgX0iAegkl2S1Evma5ImaVXLBeUkIlP6hQ1eYKQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<style>
    .form-group
    {
        position: relative;
    }
    input#phone + .validity {
  padding-right: 30px;
  width: 5px;
  height: 5px;
}
.validity{
    width: 5px;
    height: 5px;
}
input#phone:invalid+.validity:after,#phone + .validity:after {
  position: absolute; content: '✖';
  padding-left: 5px;
  color: #8b0000;
  top: 50%;
    transform: translateY(-50%);
}

input#phone:valid+.validity:after {
  position: absolute;
  content: '✓';
  padding-left: 5px;
  color: #009000;
  top: 50%;
    transform: translateY(-50%);
}

</style>


@endsection
@section('content')
    <div class="mb-4 shadow card">
        <div class="py-3 card-header d-flex">
            <h6 class="m-0 font-weight-bold text-primary">
               Створення відгука на товар
            </h6>
            <div class="ml-auto">
                <a href="{{ route('admin.reviews.index') }}" class="btn btn-primary">
                    <span class="text">Повернутись до відгуків</span>
                </a>
            </div>
        </div>
        <form action="{{route('admin.reviews.store')}}" method="POST">
            @csrf
            @method('POST')
        <div class="table-responsive">
            <table class="table table-hover">
                <tbody>
                    <tr>
                        <th>Імʼя </th>
                        <td>
                            <input class="form-control" type="text" name="first_name" value="{{ old('first_name') }}">
                             
                            @error('first_name')<span class="text-danger">{{ $message }}</span>@enderror
                            
                            
                        </td>
                        <th>Прізвище </th>
                        <td>
                            <input class="form-control" type="text" name="last_name" value="{{ old('last_name') }}">
                             
                            @error('last_name')<span class="text-danger">{{ $message }}</span>@enderror
                            
                            
                        </td>
                    </tr>
                    <tr>
                        <th>По-батькові </th>
                        <td>
                            <input class="form-control"  type="text" name="middle_name" value="{{ old('middle_name') }}">
                             
                            @error('middle_name')<span class="text-danger">{{ $message }}</span>@enderror
                            
                            
                        </td>
                        <th>Дата відгука</th>
                        <td>
                            <input class="form-control" id="datepicker" type="text" name="date" value="{{ old('middle_name') }}">
                             
                            @error('middle_name')<span class="text-danger">{{ $message }}</span>@enderror
                            
                            
                        </td>

                    </tr>
          
                    <tr >
                        <th >Текст відгука</th>
                        <td>
                            <textarea class="form-control" id="content" type="text" name="content" >{{ old('content') }}</textarea>
                            @error('content')<span class="text-danger">{{ $message }}</span>@enderror
                        </td>
                        <th >Збергти як чернетку?</th>
                        <td>
                            <input type="checkbox" name="status" {{old("status")==true?'checked':''}}>
                            @error('content')<span class="text-danger">{{ $message }}</span>@enderror
                        </td>
                    </tr>
                    
                     
                      
                     

                </tbody>
            </table>
            <button type="submit" class="m-2 btn btn-primary">Створити</button>
        </div>
    </form>
    </div>
@endsection
@section('scripts')
<script src="https://cdnjs.cloudflare.com/ajax/libs/datepicker/1.0.10/datepicker.min.js" integrity="sha512-RCgrAvvoLpP7KVgTkTctrUdv7C6t7Un3p1iaoPr1++3pybCyCsCZZN7QEHMZTcJTmcJ7jzexTO+eFpHk4OCFAg==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script>
    $().ready(()=>{
      
    $( "#datepicker" ).datepicker();
 
    })
</script>
@endsection