@extends('layouts.admin')

@section('content')
    <div class="mb-4 shadow card">
        <div class="py-3 card-header d-flex">
            <h6 class="m-0 font-weight-bold text-primary">
                Відгуки
            </h6>
            <div class="ml-auto">
                <div class="ml-auto">
                    @can('create_review')
                        <a href="{{ route('admin.reviews.create') }}" class="btn btn-primary">
                        <span class="icon text-white-50">
                            <i class="fa fa-plus"></i>
                        </span>
                            <span class="text">Новий відгук</span>
                        </a>
                    @endcan
                </div>
            </div>
        </div>

        @include('partials.backend.filter', ['model' => route('admin.reviews.index')])

        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                <tr>
                    <th>Імʼя</th>
                    <th>Додано в</th>
                    <th class="text-center" style="width: 30px;">Дії</th>
                </tr>
                </thead>
                <tbody>
                @forelse($reviews as $review)
                    <tr>
                        <td>
                            <a href="{{ route('admin.reviews.show', $review->id) }}">
                                {{ $review->fullName }}
                            </a><br>
                        </td>
                        <td>{{ $review->DateText }}</td>
                        <td>
                            <div class="btn-group btn-group-sm">
                                <a href="{{ route('admin.reviews.edit', $review) }}" class="btn btn-sm btn-primary">
                                    <i class="fa fa-edit"></i>
                                </a>
                                <a href="{{ route('admin.reviews.show', $review->id) }}" class="btn btn-sm btn-primary">
                                    <i class="fa fa-eye"></i>
                                </a>
                                <a href="javascript:void(0);"
                                   onclick="if (confirm('Are you sure to delete this record?'))
                                       {document.getElementById('delete-review-{{ $review->id }}').submit();} else {return false;}"
                                   class="btn btn-sm btn-danger">
                                    <i class="fa fa-trash"></i>
                                </a>
                            </div>
                            <form action="{{ route('admin.reviews.destroy', $review) }}"
                                  method="POST"
                                  id="delete-review-{{ $review->id }}" class="d-none">
                                @csrf
                                @method('DELETE')
                            </form>
                        </td>
     
                    </tr>
                @empty
                    <tr>
                        <td class="text-center" colspan="3">Немає відгуків</td>
                    </tr>
                @endforelse
                </tbody>
                <tfoot>
                <tr>
                    <td colspan="3">
                        <div class="float-right">
                            {!!$reviews->appends(request()->all())->links() !!}
                        </div>
                    </td>
                </tr>
                </tfoot>
            </table>
        </div>
    </div>
@endsection
