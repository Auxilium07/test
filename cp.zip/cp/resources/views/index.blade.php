	@include('parts/header')

	<article class="content">


	    <section>
	        <div class="container">
	            <div id="mainLoading" class="loader-box">
	                <div class="loader-wrapper">
	                    <div class="sk-fading-circle">
	                        <div class="sk-circle1 sk-circle"></div>
	                        <div class="sk-circle2 sk-circle"></div>
	                        <div class="sk-circle3 sk-circle"></div>
	                        <div class="sk-circle4 sk-circle"></div>
	                        <div class="sk-circle5 sk-circle"></div>
	                        <div class="sk-circle6 sk-circle"></div>
	                        <div class="sk-circle7 sk-circle"></div>
	                        <div class="sk-circle8 sk-circle"></div>
	                        <div class="sk-circle9 sk-circle"></div>
	                        <div class="sk-circle10 sk-circle"></div>
	                        <div class="sk-circle11 sk-circle"></div>
	                        <div class="sk-circle12 sk-circle"></div>
	                    </div>
	                </div>
	                <form method="POST" action="/" class="main-change-box js-OrderForm" data-lang="/">
	                    @csrf
	                    <input type="hidden" name="sessid" id="sessid_3" value="907a9c50eefb3d2dd31dc13e130faf8c">
	                    <div class="change-field long">
	                        <div class="column">
	                            <div class="title title-custom">Отправить<span>шаг 1</span>
	                                <div class="system-icon search-custom">
	                                    <input class="form-control" type="text" name="get">
	                                    <p class="help-block help-block-error">Поле не должно быть пустым</p>
	                                    <div class="img btn-search-custom"><img
	                                            src="{{asset("storage/images/icon-search.svg")}}" alt=""></div>
	                                </div>
	                            </div>
	                            <fieldset class="choose-system" id="system-give">
	                                <legend>Выберите систему:</legend>
	                                @if($currencies[0])
	                                @foreach($currencies[0] as $item)

	                                <label>
	                                    <input type="radio" name="system-give" data-codecurency="{{$item['id']}}"
	                                        data-curency="COIN" data-send-precision="2" value="{{$item['id']}}">
	                                    <span>{{$item["name"]}}
	                                        {{$item["name"]!=$item['symbol']?"(".strtoupper($item['symbol']).")":''}}</span>
	                                    <div class="img">
	                                        <img src="{{$item["image"]}} " class="table-icon"
	                                            alt="{{$item["name"]}} {{$item["name"]!=$item['symbol']?"(".$item['symbol'].")":''}}"
	                                            onerror="this.style.display='none';">
	                                    </div>
	                                </label>
	                                @endforeach

	                                @else
	                                <span><?php __("error")?></span>
	                                @endif
	                            </fieldset>
	                        </div>
	                        <div class="column">
	                            <div class="title title-custom">Получить<span>шаг 2</span>
	                                <div class="system-icon search-custom">
	                                    <input class="form-control" type="text" name="get">
	                                    <p class="help-block help-block-error">Поле не должно быть пустым</p>
	                                    <div class="img btn-search-custom"><img
	                                            src="{{asset("storage/images/icon-search.svg")}}" alt=""></div>
	                                </div>
	                            </div>
	                            <fieldset class="choose-system" id="system-get">
	                                <legend>Выберите систему:</legend>
	                                @if($currencies[1])
	                                @foreach($currencies[1] as $item)

	                                <label id="{{$item['id']}}" class="hidden">
	                                    <input type="radio" name="system-get" data-codecurency="{{$item['id']}}"
	                                        data-curency="COIN" data-send-precision="2" value="{{$item['id']}}">
	                                    <span>{{$item["name"]}}
	                                        {{$item["name"]!=$item['symbol']?"(".strtoupper($item['symbol']).")":''}}</span>
	                                    <div class="img">
	                                        <img src="{{$item["image"]}} " class="table-icon"
	                                            alt="{{$item["name"]}} {{$item["name"]!=$item['symbol']?"(".$item['symbol'].")":''}}"
	                                            onerror="this.style.display='none';" style="display: none">
	                                    </div>
	                                </label>

	                                @endforeach

	                                @else
	                                <span><?php __("error")?></span>
	                                @endif

	                            </fieldset>
	                        </div>
	                    </div>
	                    <div id="direction_field" class="change-field loader-box data">
	                        <input name="make_order" type="hidden" value="Create order">
	                        <input type="hidden" name="direction_code" value="">
	                        <input type="hidden" id="min_send_amount" value="">
	                        <input type="hidden" id="min_send_amount_direction" value="TO">
	                        <input type="hidden" id="max_send_amount" value="">
	                        <input type="hidden" id="max_send_amount_direction" value="TO">
	                        <input type="hidden" id="receive_limit" value="">
	                        <input type="hidden" id="receive_currency" value="">
	                        <input type="hidden" name="currency_one" id="currency_one" value="">
	                        <input type="hidden" name="currency_two" id="currency_two" value="">
	                        <!--					-->
	                        <div class="title">Ввод данных<span>шаг 3</span>
	                        </div>
	                        <div class="search-right-cuatom">

	                            <div class="name-mute">
	                                <span>Отправить</span>
	                                <span class="pull-right"></span>
	                            </div>
	                            <div class="form-group system-icon">
	                                <input class="form-control " type="text" id="field_amount" name="amount" value=""
	                                    data-required="" data-validation="float" data-decimal="2" data-expr=""
	                                    data-error="">
	                                <span class="field_loader_calc"></span>
	                                <p class="help-block help-block-error js-error ">
	                                </p>
	                                <div class="img"><img src="images/623bf9040d206.svg" alt="" style="display: none">
	                                </div>
	                            </div>
	                            <div class="name-mute">Получить</div>
	                            <div id="box_you_receive" class="form-group system-icon">
	                                <input class="form-control " type="text" id="field_amount_to" name="amount_to" value=""
	                                    data-validation="float" data-decimal="2" data-expr="" data-error="">
	                                <span class="field_loader_calc"></span>
	                                <p class="help-block help-block-error js-error ">
	                                </p>
	                                <div class="img"><img src="{{asset("storage/images/66ead13d863d7.svg")}}" alt=""
	                                        style="display: none"></div>
	                            </div>
	                            <div id="reserve" data-name="Резерв" class="name-mute summ">
	                            </div>
	                        </div>

	                        <div class="inf-form" id="currency-info">
	                            <div class="inf-form__btn"><span>Показать дополнительную информацию</span></div>
	                            <div class="inf-form__main">
	                                <p>
	                                    <b>Курс</b>
	                                    <span class="pull-right"></span>
	                                </p>
	                                <p>
	                                    <b>Резерв</b>
	                                    <span class="pull-right"></span>
	                                </p>
	                                <p>
	                                    <b>Мин. сумма</b>
	                                    <span class="pull-right">
	                                    </span>
	                                </p>
	                                <p>
	                                    <b>Макс. сумма</b>
	                                    <span class="pull-right">
	                                    </span>
	                                </p>
	                            </div>
	                        </div>

	                        <div class="form-group ">
	                            <input type="text" id="field_user_email" name="email" data-validate="" data-type="email"
	                                data-expr="" data-error="" value="" placeholder="Електронная почта" class="form-control"
	                                required="required">


	                            <p class="help-block help-block-error js-error ">
	                            </p>

	                        </div>
	                        <div class="form-group ">
	                            <input type="text" id="field_user_phone" name="phone" data-validate="" data-type="phone"
	                                data-expr="" data-error="" value="" placeholder="Номер телефона" class="form-control"
	                                required="required">


	                            <p class="help-block help-block-error js-error ">
	                            </p>

	                        </div>
	                        <div class="form-group ">
	                            <input type="text" id="field_account" name="wallet" value="" placeholder=" кошелек"
	                                class="form-control" required="required">


	                            <p class="help-block help-block-error js-error ">
	                            </p>

	                        </div>
	                        <div class="form-group">
	                            <label class="checkbox">
	                                <input type="checkbox" required="required" name="i_agree" value="Y"
	                                    class="js-Agreements">
	                                <span>
	                                    Я согласен с <a href="/tеrms_of_service/" target="_blank"
	                                        class="more u_hover"><u>Пользовательским соглашением</u></a>
	                                </span>
	                            </label>
	                            <p class="help-block help-block-error "></p>
	                        </div>
	                        <div class="form-group">
	                            <label class="checkbox">
	                                <input type="checkbox" required="required" name="i_agree_aml" value="Y"
	                                    class="js-Agreements">
	                                <span>
	                                    Я согласен с <a href="/privacy_policy/" target="_blank"
	                                        class="more u_hover"><u>Политикой AML</u></a>
	                                </span>
	                            </label>
	                            <p class="help-block help-block-error "></p>
	                        </div>

	                        <input name="make_order" type="hidden" value="Create order">
	                        <button class="btn btn-default js_submit_btn" disabled="">Обменять сейчас</button>
@if (count($reviews)>0)
<h3>Отзывы</h3>
<div class="reviews-slider">


@foreach ($reviews as $review)
    

<div class="one-item">
    <p>{{$review->content}}</p>
    <div class="review-info">
                            <div class="when">{{$review->DateText}}</div>
                            <div class="who">{{$review->fullname}}</div>
    </div>
</div>
@endforeach
</div>
@endif
	                       
	                    </div>

	                </form>
	            </div>
	        </div>
	    </section>


	    <script>
	        lang_error = {
	            min_send: "Минимальная сумма отправки — ",
	            max_send: "Максимальная сумма отправки — ",
	            max_receive: "Максимальная сумма получения — ",
	            min_receive: "Минимальная сумма получения — ",
	            badvalue: "Неверное значение",
	            bademail: "Это поле содержит недопустимое значение. Это должен быть адрес электронной почты",
	            badnumber: "Поле должно содержать только цифры"
	        };
	        lang = "/";
	        $(document).ready(function () {});

	        var cards = {
	            'FROM': {
	                'field_number': 'from_account',
	                'field_holder': 'from_fio',
	                'cards': []
	            },
	            'TO': {
	                'field_number': 'to_account',
	                'field_holder': 'to_fio',
	                'cards': []
	            }
	        };
	        var cards_list = null;
	        var cards_holders_list = {};

	        lang_error = {
	            min_send: "Минимальная сумма отправки",
	            max_send: "Максимальная сумма отправки",
	            max_receive: "Максимальная сумма получения",
	            min_receive: "Минимальная сумма получения",
	            badvalue: "Неверное значение",
	            bademail: "Это поле содержит недопустимое значение. Это должен быть адрес электронной почты",
	            badnumber: "Поле должно содержать только цифры"
	        };

	        for (var i in cards) {
	            var direction_cards = cards[i];
	            var field_number = direction_cards.field_number;
	            var field_holder = direction_cards.field_holder;
	            var direction_cards_list = Object.assign({}, direction_cards.cards);

	            if (!direction_cards_list)
	                continue;

	            cards_list = [];

	            for (var ii in direction_cards_list) {
	                var card = direction_cards_list[ii];
	                var number = card['NUMBER'];

	                if (!number)
	                    continue;

	                cards_list.push(number);
	            }

	            var o2 = Object.assign({}, direction_cards_list);

	            if (!!$('#field_' + field_number).length && cards_list.length > 0)
	                createAutocomplete($('#field_' + field_number), $('#field_' + field_holder), cards_list,
	                    direction_cards_list);
	        }

	        function createAutocomplete($field_number, $field_holder, cards, holders) {
	            $($field_number).autocomplete({
	                minChars: 0,
	                delimiter: /(,|;)\s*/, // Разделитель для нескольких запросов, символ или регулярное выражение
	                maxHeight: 400,
	                width: 428,
	                zIndex: 9999,
	                deferRequestBy: 0,
	                onSelect: function (data) {
	                    var value = data.value.toString().trim();
	                    var card = holders['N_' + value];
	                    var holder = (card ? card['HOLDER'] : '');

	                    $(this).change();
	                    $($field_holder).val(holder).prop('readonly', !!holder).toggleClass('has-success', !!
	                        holder);
	                },
	                lookup: cards
	            }).change(function () {
	                var value = $(this).val();

	                if (!('N_' + value in holders))
	                    $($field_holder).attr('readonly', false).prop('readonly', false).removeClass(
	                    'has-success');

	            }).parent().css('position', 'relative').append('<div class="search_icon"></div>');
	        }
	    </script>
	    <section>
	        <div class="container">
	            <script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.min.js"
	                integrity="sha512-HGOnQO9+SP1V92SrtZfjqxxtLmVzqZpjFFekvzZVWoiASSQgSr4cw9Kqd2+l8Llp4Gm0G8GIFJ4ddwZilcdb8A=="
	                crossorigin="anonymous" referrerpolicy="no-referrer"></script>

	            <style>
	                @import url("https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick-theme.min.css");
	                @import url("https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.min.css");
	            </style>
	            
	        </div>
	    </section>
	</article>


	@include('parts/footer')