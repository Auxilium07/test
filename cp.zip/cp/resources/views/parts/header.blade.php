<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>

<?php if(isset($keywords)){ ?>
<meta name="keywords" content="{{$keywords}}"><?php }?>
<link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Ubuntu:700&amp;subset=cyrillic"
type="text/css" rel="stylesheet">
@vite(['resources/css/app.css', 'resources/js/app.js','resources/js/chosen.jquery.min.js',
'resources/css/chosen.css',"resources/js/jquery-ui.min.js"])
<meta http-equiv="content-language" content="{{ str_replace('_', '-', app()->getLocale()) }}">
<meta name="viewport" content="width=960">
<link rel="shortcut icon" href="{{ asset('favicon.ico') }}">
<link rel="apple-touch-icon" sizes="180x180" href="{{asset('images/apple-touch-icon.png')}}">
<link rel="icon" type="image/png" sizes="32x32" href="{{asset('images/favicon-32x32.png')}}">
<link rel="mask-icon" href="{{asset('images/safari-pinned-tab.svg')}}" color="#2d8ec0">
<meta name="msapplication-TileColor" content="#ffffff">
<meta name="theme-color" content="#ffffff">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.css"
integrity="sha512-3pIirOrwegjM6erE5gPSwkUzO+3cTjpnV9lexlNZqvupR64iZBnOOTiiLPb9M36zpMScbmUNIcHUqKD47M719g=="
crossorigin="anonymous" referrerpolicy="no-referrer" />
<script defer src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"
integrity="sha512-VEd+nq25CkR676O+pLBnDW09R7VQX9Mdiij052gVCp5yVH3jGtH70Ho/UUv4mJDsEdTvqRCFZg0NKGiojGnUCw=="
crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="https://code.jquery.com/jquery-3.7.1.min.js"
integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>

<title>{{env("APP_NAME")}} - купить, продать, обменять Perfect Money, Bitcoin и т. д.</title>
<script>
window.lang = "{{ str_replace('_', '-', app()->getLocale()) }}";
</script>
</head>

<body>

<div class="box">
<div class="booty">
<header>
<div class="container">
<div class="row">
<div class="col-xs-12">
<div class="pull-right">

</div>

</div>
</div>
<div class="row">
<div class="col-xs-12">

<a href="/" class="logo"></a>

</div>
</div>
</div>
</header>
</div>