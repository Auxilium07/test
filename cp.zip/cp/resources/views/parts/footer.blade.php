</div>
<div class="footer_clear"></div>

<footer>
<div class="container">
<div class="pull-right">
<ul class="bottom-menu">
<li><a href="/tеrms_of_service/">Пользовательское соглашение</a></li>
<li><a href="/privacy_policy/">Политика AML</a></li>
</ul>

</div>


</div>
<div class="text-center bg-blue-middle2">
© 2024, {{ env('APP_NAME') }}, {{__("rights")}}
</div>
<br> </footer>

</body></html>