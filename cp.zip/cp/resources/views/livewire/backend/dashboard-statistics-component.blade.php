<div class="row">
    <!-- Earnings (Monthly) Card Example -->
    <div class="mb-4 col-xl-3 col-md-6">
        <div class="py-2 shadow card border-left-primary h-100">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="mr-2 col">
                        <div class="mb-1 text-xs font-weight-bold text-primary text-uppercase">
                            Earnings (Monthly)
                        </div>
                        <div class="mb-0 text-gray-800 h5 font-weight-bold">${{ number_format($currentMonthEarning, 2) }}</div>
                    </div>
                    <div class="col-auto">
                        <i class="text-gray-300 fas fa-calendar fa-2x"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Earnings (Monthly) Card Example -->
    <div class="mb-4 col-xl-3 col-md-6">
        <div class="py-2 shadow card border-left-success h-100">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="mr-2 col">
                        <div class="mb-1 text-xs font-weight-bold text-success text-uppercase">
                            Earnings (Annual)
                        </div>
                        <div class="mb-0 text-gray-800 h5 font-weight-bold">${{ number_format($currentAnnualEarning, 2) }}</div>
                    </div>
                    <div class="col-auto">
                        <i class="text-gray-300 fas fa-dollar-sign fa-2x"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Earnings (Monthly) Card Example -->
    <div class="mb-4 col-xl-3 col-md-6">
        <div class="py-2 shadow card border-left-info h-100">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="mr-2 col">
                        <div class="mb-1 text-xs font-weight-bold text-info text-uppercase">
                            New Orders (Monthly)
                        </div>
                        <div class="mb-0 text-gray-800 h5 font-weight-bold">{{ $currentMonthOrderNew }}</div>
                    </div>
                    <div class="col-auto">
                        <i class="text-gray-300 fas fa-shopping-cart fa-2x"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Pending Requests Card Example -->
    <div class="mb-4 col-xl-3 col-md-6">
        <div class="py-2 shadow card border-left-warning h-100">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="mr-2 col">
                        <div class="mb-1 text-xs font-weight-bold text-warning text-uppercase">
                            Finished Orders (Monthly)
                        </div>
                        <div class="mb-0 text-gray-800 h5 font-weight-bold">{{ $currentMonthOrderFinished }}</div>
                    </div>
                    <div class="col-auto">
                        <i class="text-gray-300 fas fa-shopping-basket fa-2x"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
