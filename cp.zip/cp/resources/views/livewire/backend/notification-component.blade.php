<div>
    <a class="nav-link dropdown-toggle" href="#" id="alertsDropdown" role="button"
       data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        <i class="fas fa-bell fa-fw"></i>
        <!-- Counter - Alerts -->
        <span class="badge badge-danger badge-counter">{{ isset($unReadNotificationsCount)?$unReadNotificationsCount:'-' }}</span>
    </a>
    <!-- Dropdown - Alerts -->
    <div class="shadow dropdown-list dropdown-menu dropdown-menu-right animated--grow-in"
         aria-labelledby="alertsDropdown">
        <h6 class="dropdown-header">
            Центр сповіщень
        </h6>
        @if (isset($unReadNotifications ))
            
        @forelse($unReadNotifications as $notification)
        <a class="dropdown-item d-flex align-items-center" wire:click="markAsRead('{{ $notification->id }}')">
            <div class="mr-3">
                <div class="icon-circle bg-primary">
                    <i class="text-white fas fa-file-alt"></i>
                </div>
            </div>
            <div>

                <div class="text-gray-500 small">{{ $notification->data['created_date'] }}</div>
               
                    <span class="font-weight-bold">
                        Нова заявка
                    </span>
                
            </div>
        </a>
        @empty
            <div class="text-center dropdown-item">Повідомлень не знайдено!</div>
        @endforelse
        @endif
        
{{--        <a class="text-center text-gray-500 dropdown-item small" href="#">Show All Alerts</a>--}}
    </div>
</div>
