<div class="py-3">
   
    @forelse($messages as $message)
        <div class="w-full px-3 border">
            <div class="w-full justify-content-between d-flex align-content-between">
                <div>{{ $message->user->username }} : {{ $message->created_at->format('d-m-Y h:i a') }}</div>
                <div> 
                           
                                  <button type="button" wire:click="delete({{$message->id}},{{$order_id}})"
                               class="btn btn-sm btn-danger">
                                <i class="fa fa-trash"></i>
                            </button>
                            
                            
                        </div>
                        </div>
            
            <p class="p-2 border">
          {{ $message->message }}</p>
        </div>
       
    @empty
        <div class="px-3">
            Попередніх коментарів немає
        </div>
    @endforelse
    
</div>