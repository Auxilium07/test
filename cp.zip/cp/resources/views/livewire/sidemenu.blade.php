<div>
     <!-- Nav Item - Pages Collapse Menu -->
     @if($admin_side_menu)
    
     @forelse($admin_side_menu as $link)
  
    @can($link->permission_title)
       
         @if(in_array($link->to, $routes_name))
         <div class="nav-item {{Request::url() == route($link->to) ? "active":""}}">
                     <a class="nav-link" href="{{ route($link->to) }}">
                         <i class="{{ $link->icon }}"></i>
                         {{ $link->title }}
                     </a>
                 @endif
                    </div>

 @endcan
@empty
@endforelse
   
    @endif
</div>