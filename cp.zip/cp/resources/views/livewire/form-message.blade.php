<div>
    
    <form wire:submit="save" class="p-3 form-group">
        <textarea class="w-full form-control" wire:model="content"></textarea>
        <input type="hidden" value="{{$user_id}}" wire:model="user_id">
        <button type="submit" class="my-2 btn btn-primary">Відправити</button>
    </form>
    @error('content') <span class="error">{{ $message }}</span> @enderror 
</div>
