<div>
    <form wire:submit="save" class="d-flex">
        <input type="hidden" wire:model="order_id" value="{{$order_id}}">
        <select class="form-control"  wire:model="status" name='status' wire:change="save" style="outline-style: none;">
        <option disabled {{!in_array($current_status,array_keys($orderStatusArray))?"selected":''}}> Оберіть статус </option>
        @foreach($orderStatusArray as $key => $value)
            <option value="{{ $key }}" {{$key== $current_status?'selected':''}}>{{ $value }}</option>
        @endforeach
    </select>
    
    </form>
    @script
<script>
     document.addEventListener('livewire:initialized', function () {
            $selected=$("[name='status'] option[value='{{$current_status}}']")[0].selected=true;
        })
</script>
@endscript

</div>
