
$(document).ready(function() {
    var send_prec = $('[name=system-get]:checked').attr('data-send-precision'),
        reseive_prec = $('[name=system-get]:checked').attr('data-receive-precision');

    $('#field_amount').attr('data-decimal', send_prec);
    $('#field_amount_to').attr('data-decimal', reseive_prec);

	// Вывод списка доступных "валют" для выбранной
	$('[name=system-give]').on('click', function() {
		var curency = $(this),
	        code 	= curency.val(),
            $img = $(this).parent().find('img').attr('src');
            $(this).parent().find('img').css("display","block")
            
            $('#field_amount').parent().find("img").css("display","block")
        $(this).attr('checked',true).parent('#system-give').find('checked').attr('checked',false);
        $('#field_amount').parent().find("img").attr('src', $img)
        $('#box_you_send').find('img').attr('src', $img);
        $(".data").addClass('loading');
        $('#system-get').find('label').removeClass("hidden").addClass('active');
		// $('#system-get').find('label').each(function(){
            
		//     if($(this).attr('id') == code){
        //         $(this).removeClass("hidden").addClass('active');
                
        //     } else {
        //         $(this).addClass("hidden").removeClass("active")
        //     }
        // })


	});

    $('[name=system-get]').on('click', function(e) {
        var $imgGet = $(this).parent().find('img').attr('src'),
            $reservGet = $(this).data('reserve'),
            $curencyGet = $(this).data('curency'),
            $reserveTxt = $('#reserve').data('name'),
            $direction = $(this).attr('data-directioncode'),
            send_prec = $('[name=system-give]:checked').attr('data-send-precision'),
            reseive_prec = $(this).attr('data-receive-precision'),
            curr1=$('[name=system-give]:checked').val(),
            curr2=$(e.target).val();
            $('[name=system-get]').attr("checked",false);
            $('[value="'+curr2+'"]').attr("checked",true);
            console.log($(e.target).val());
           
        $("#mainLoading").addClass('loading');
        $.ajax({
            method: "GET",
            url: window.location.protocol+"//"+window.location.host +'/api/get_directions?curr1='+curr1+'&curr2='+curr2+'&lang='+     document.querySelector("html").getAttribute("lang"),
        })
        .always(function() {
            
            $("#mainLoading").removeClass('loading');
            $(".data").removeClass('loading');
        })
        .done(function( data ) {
            
            data=JSON.parse(data);

            $('#field_amount').attr('data-decimal', send_prec);
            $('#field_amount_to').attr('data-decimal', reseive_prec);
            
            $('#box_you_receive').find('.img').html('<img src="' + $imgGet + '" alt="">');
            $('#reserve').removeClass('hidden').html($reserveTxt + ': ' + data[1].total_supply + ' ' + curr2);
            $('.name-mute span.pull-right').html("Курс "+data[0].current_price+":1 ");
            $('#field_account').attr("placeholder",data[1].name+" кошелек")
            let tmp=`
                                                                <p>
                                        <b>Курс</b>
                                        <span class="pull-right">${data[0].current_price} : 1</span>
                                    </p>
                                                                                            <p>
                                    <b>Резерв</b>
                                    <span class="pull-right">${data[1].total_supply } ${data[1].symbol.toUpperCase() } </span>
                                </p>
                                                                <p>
                                        <b>Мин. сумма</b>
                                        <span class="pull-right">
                                    ${data[0].current_price*1.5} ${data[0].symbol.toUpperCase() }</span>
                                    </p>
                                                                    <p>
                                        <b>Макс. сумма</b>
                                        <span class="pull-right">
                                            ${data[0].current_price*3} ${data[0].symbol.toUpperCase() }</span>
                                    </p>
                                                           `;
            $('#direction_code').val(data[0].symbol+'-'+data[1].symbol);
            $('#min_send_amount').val(data[0].current_price*1.5);
            $('#max_send_amount').val(data[0].current_price*3);
            $('#receive_limit').val(data[1].total_supply)
            $('#receive_currency').val(data[1].symbol)
            $('#currency_one').val(data[0].id)
            $('#currency_two').val(data[1].id)
            $('#currency-info .inf-form__main').html(tmp);
            if($('#field_amount').val() != '') {
                get_summ($direction, $('#field_amount').val(), false,  $('#field_region option:selected').val());
            }
            $('.chosen-select').chosen({
                placeholder_text_multiple: " ",
                disable_search_threshold: 10,
                search_contains: true
            });
            
            
        });
        
        return false;
    });
    $('.reviews-slider').slick({
        slidesToShow: 3,
        slidesToScroll: 2,
        autoplay: true,
        vertical: true,
        verticalSwiping: true,
        initialSlide: 2
    });
});

$(".inf-form__btn").on("click",(e)=>{
    
    let info= e.target//document.querySelector(".inf-form__btn+.inf-form__main");
    info.parentNode.classList.toggle("open");
    if(!info.parentNode.classList.contains("open"))
    {
        $(e.target).html("Показать дополнительную информацию");
    }
    else{
        $(e.target).html("Скрыть дополнительную информацию");
    }
})

$(document).on('change', "#field_region",function (){
    var $this 		= this;
    var region 		= $($this).find('option:selected').val();
    var $send 		= $('#field_amount');
    var $receive 	= $('#field_amount_to');
    var direction 	= $('input[name="direction_code"]').val();
    var amount 		= $($send).val() ? parseFloat($($send).val().replace(/,/, '.')) : 0;

    $($this).closest('.form-group').removeClass('has-error').find('.js-error').css('display', '').html('');
    if(!region) {
        $($this).closest('.form-group').addClass('has-error').find('.js-error').css('display', '').html(fmq_lang_default_settings.required);
        return false;
    }

    $($receive).val('');
    if(amount > 0)
        get_summ(direction, amount, false, region);
});
$(document).on('click', '.js-Agreements', function() {

    var $btn 	= $('.js-OrderForm').find(".js_submit_btn");
    var checked = !$(this).prop("checked");

    $($btn).prop('disabled', checked);
});

/*фильтр*/
$(document).on('click', '[data-filter]', function () {
    var currencyFilter = $(this).val(),
        currencyDirect = $('[name=system-give]:checked').val(),
        type = $(this).attr('data-filter-type');

    $('#system-'+type+' input').each(function () {
        var currency = $(this).attr('data-curency'),
            curId = $(this).closest('label').attr('id');

        if(type === 'get') {
            if(curId === currencyDirect) {
                if (currency !== currencyFilter && currencyFilter !== '') {
                    $(this).parent().addClass('hidden');
                } else {
                    $(this).parent().removeClass('hidden');
                }
            }
        } else if (type === 'give') {
            if (currency !== currencyFilter && currencyFilter !== '') {
                $(this).parent().addClass('hidden');
            } else {
                $(this).parent().removeClass('hidden');
            }
        }
    });
});

// редирект на выбранное направление
$('td', '.direction-tbl tr').on('click', function() {
    var link = $(this).closest('tr').data('link');

    if(link)
        window.location.assign(link);
});

var debounce_get_summ = debounce(get_summ, 250) ;

/**********************************/
/*оформление заявки*/
$(document).on('blur, keyup', '#field_amount, #field_amount_to', function () {
    var val = $(this).val();
    var summ = '';
    var cursumm = parseFloat($(this).attr('rel'));
    var id = $(this).attr('id');
    var reverse = 0;
    var code = $('input[name="direction_code"]').val();
    var region = $('#field_region option:selected').val();
    var prec = parseInt($(this).attr('data-decimal'));

    fixSumm($(this), val, prec);
    summ = parseFloat(val);

    if(region == ''){
        $("#field_region").parent().addClass('has-error').find('.js-error').css('display', '').html(fmq_lang_default_settings.required);
        return false;
    }

    if(summ != cursumm && summ > 0) {
        if (id == 'field_amount_to') {
            reverse = 1;
        }
        debounce_get_summ(code, summ, reverse, region);
    }
});

$(document).on('change', '#crypto_network', function (){
    var code = $(this).val();
    if (code) {
        $('.js_submit_btn').attr('disabled', 'disabled');
        location.href = '?direction=' + code + '';
    }
});
$(".js-OrderForm").on("submit",(e)=>{
    e.preventDefault();
    console.log(e.target);
    var form=new FormData(e.target);
    $.ajax({
        method: 'POST',
        url: window.location.protocol+"//"+window.location.host +'/api/create_order',
        data:form,
        processData: false,
contentType: false
    }).done((data)=>{
        
        toastr.info("Ваша заявка на обмен доставлена. В ближайшее врямя с вами свяжутся.");
        $(".js-OrderForm")[0].reset();
    }
    )
    
})
function fixSumm(elem, val, prec){


    elem.val(val.replace(/[^\d,.]/g, ''));
    let sum = val.replace(/,/, '.');
    let result = sum;
    let sumSplit = sum.split('.');
    if(sumSplit[1]) {
        result = sumSplit[0]+'.'+sumSplit[1].slice(0,prec);
        elem.val(result);
    }

    return result;
}
function toNumberString(num) {
    if (Number.isInteger(num)) {
        return num;
    } else {
        return num.toString();
    }
}

function debounce(func, wait, immediate) {
    var timeout;
    return function() {
        var context = this, args = arguments;
        var later = function() {
            timeout = null;
            if (!immediate) func.apply(context, args);
        };
        var callNow = immediate && !timeout;
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
        if (callNow) func.apply(context, args);
    };
};
$(document).on('change blur', '#field_from_account', function () {
    var direction 		= $('input[name="direction_code"]').val();
    var account_number 	= $(this).val();
    var type 			= $(this).data('type');

    $(this).closest('.form-group').removeClass('has-error').find('.js-error').css('display', '').html('');

    if(!account_number)
        return true;

    try {
        var expr = '';

        switch(type) {
            case 'int':
            case 'float':
                expr = /\d+/;

                if(!expr.test(account_number))
                    throw lang_error.badnumber;

                break;
            case 'email':
                expr = /[a-z\d._%+-]+@[a-z\d.-]+\.[a-z]{2,8}\b/ui;

                if(!expr.test(account_number))
                    throw lang_error.bademail;

                break;
            case 'regex':
                expr = $(this).attr('data-expr');

                if(expr) {
                    var flags = expr.replace(/.*\/([gimy]*)$/, '$1');
                    var pattern = expr.replace(new RegExp('^/(.*?)/'+flags+'$'), '$1');
                    var regex = new RegExp(pattern, flags);

                    if(regex && !regex.test(account_number))
                        throw lang_error.badvalue;
                }

                break;
            default:
                break;
        }

        
    }
    catch(error) {
        if(typeof error !== 'string')
            error = 'Undefined error';

        $(this).addClass('has-error').find('.js-error').css('display', '').html(error);
        return false;
    }
});

$(document).on('blur, keyup', '[data-validate]', function () {
    var regExp 	= new RegExp($(this).data('expr'));
    var value 	= $(this).val();

    $(this).closest('.form-group').removeClass('has-error').find('.js-error').css({'display':'none'}).removeClass('active').html('');
    if(value && !regExp.test(value))
        $(this).closest('.form-group').addClass('has-error').find('.js-error').css({'display':'block'}).addClass('active').html(lang_error.badvalue);
});

function get_summ(direction, amount, reverse, region) {
    var error 				= '';
    var $error_field 		= null;

    var $amount 			= $('#field_amount');
    var $amount_to 			= $('#field_amount_to');
    var $btn 				= $('.js_submit_btn');

    var min 				= $('#min_send_amount').val() - 0;
    var min_direction 		= $('#min_send_amount_direction').val();
    var max 				= $('#max_send_amount').val() - 0;
    var max_direction 		= $('#max_send_amount_direction').val();
    var max_receive 		= $('#receive_limit').val() - 0;

    var lang                =     document.querySelector("html").getAttribute("lang");
    // ограничения на отправку
    var minFrom = (min_direction === 'FROM' ? min : false);
    var maxFrom = (max_direction === 'FROM' ? max : false);

    // ограничения на прием
    var minTo = (min_direction === 'TO' ? min : false);
    var maxTo = (max_direction === 'TO' ? max : false);
    var validation = $amount_to.attr('data-validation');

    // запрет на отправку отрицательной суммы
    if(minFrom < 0)
        minFrom = 0;

    // ограничение на максимальную сумму для получения
    if(maxTo > max_receive)
        maxTo = max_receive;

    $($amount).closest('.form-group').removeClass('has-error').find('.js-error').css({'display':''}).removeClass('active').html('');
    $($amount_to).closest('.form-group').removeClass('has-error').find('.js-error').css({'display':''}).removeClass('active').html('');

    // проверяем лимиты и формируем код ошибки
    error = getSumError(amount, (reverse ? minTo : minFrom),(reverse ? maxTo : maxFrom) , (reverse ? 'Y' : 'N'));
    if(error)
        $error_field = (reverse ? $amount_to : $amount);

    if (validation === 'int' && !Number.isInteger(amount)) {
        $error_field = $amount_to;
        error = fmq_lang_default_settings.not_integer;
    }
    try {
        if(error) {
            $($error_field).closest('.form-group').addClass('has-error').find('.js-error').css({'display':'block'}).addClass('active').html(error);
            // $('#reserve').css({'display':'none'}).removeClass('active');
            throw '';
        } /*else {
            $('#reserve').css({'display':'block'}).addClass('active');
        }*/

        $($amount).closest('.loader-box').addClass('loading');
        $($amount_to).closest('.loader-box').addClass('loading');

        $($btn).prop('disabled', true);
        let curr1=$('[name=system-give]:checked').val(),
        curr2=$('[name=system-get][checked]').val();
        $.ajax({
            method: "GET",
            url: window.location.protocol+"//"+window.location.host +'/api/calculate?curr1='+curr1+'&curr2='+curr2+'&amount='+$amount[0].value+'&lang='+lang,
            
           
        })
            .always(function() {

                $($amount).prop('disabled', false).closest('.loader-box').removeClass('loading');
                $($amount_to).prop('disabled', false).closest('.loader-box').removeClass('loading');

                if($(".js-Agreements").is(':checked'))
                    $($btn).prop('disabled', false);
            })
            .done(function(data) {
                
                var receive_currency 	= $('#receive_currency').val();
                var receive 			= data.AMOUNT;
                var commission 			= data.COMMISSION;
              

                try{
                    error = data.ERRORS && data.ERRORS.get_r_sum ? data.ERRORS.get_r_sum[0] : '';

                    // устанавливаем сумму отправления\сумму получения
                    var sumSend 	= (reverse ? receive : amount) - 0;
                    var sumReceive 	= (reverse ? amount : receive) - 0;
                    // проверяем лимиты и формируем код ошибки
                    $error_field = $amount;
                    if(error === '') {
                        error = getSumError(sumSend, minFrom, maxFrom, 'N'); // отправляемая сумма
                        if (!error) {
                            error = getSumError(sumReceive, minTo, maxTo, 'Y'); // получаемая сумма

                            if (!!error) {
                                $error_field = $amount_to;
                            }
                            if (validation === 'int' && !Number.isInteger(sumReceive)) {
                                $error_field = $amount_to;
                                error = fmq_lang_default_settings.not_integer;
                            }
                        } else {
                            $error_field = $amount;
                        }
                    }

                    if(error) {
                        throw '';
                    }

                    $('#region_commission').parent('tr').toggleClass('hidden', true);
                    if(commission)
                        $('#region_commission').html(commission + ' ' + receive_currency).parent('tr').removeClass('hidden');
                }
                catch(e) {

                }

                if(error) {
                    $($error_field).closest('.form-group').addClass('has-error').find('.js-error').css({'display':'block'}).addClass('active').html(error);
                    // $('#reserve').css({'display':'none'}).removeClass('active');
                } /*else {
                    $('#reserve').css({'display':'block'}).addClass('active');

                }*/

                $((reverse === 1 ? $amount : $amount_to)).val(receive);
            });
    }
    catch(e) {
        toastr.error('Inernal error, try again later')
        console.log(e);
        $((reverse === 1 ? $amount : $amount_to)).val('');
    }
  }

/** Проверяет входит ли сумма в указанный диапозон.
 *
 * @param sum
 * @param min
 * @param max
 * @param reverse
 * @returns {string}
 */
function getSumError(sum, min, max, reverse) {
    reverse 	= reverse || 'N';

    var error 	= '';
    var value 	= '';

    if(min !== false && sum < min) {
        error = 'min';
    } else if(max !== false && sum > max) {
        error = 'max';
    }
    if(error) {
        value = (error === 'max' ? max : min);
        error += (reverse === 'Y' ? '_receive' : '_send');
    }

    if(error) {
        error = lang_error[error] + (value ? ' ' + value : '');
    }

    return error;
}

/* End */
;; /* /local/templates/openchange/components/fmq/directions/.default/script.js?168083684116563*/
