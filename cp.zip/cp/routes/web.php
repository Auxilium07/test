<?php

use App\Http\Controllers\Frontend\HomeController;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;

Auth::routes(['verify' => true]);

Route::get('/', [HomeController::class,"Index"]);

Route::get('/privacy_policy/', function(){
    return view("privacy");
});
Route::get('/tеrms_of_service/', function(){
    return view("tеrms");
});

