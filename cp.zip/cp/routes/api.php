<?php

use App\Http\Controllers\API\CurrencyController;
use App\Http\Controllers\Frontend\OrdersController;
use Illuminate\Support\Facades\Route;


Route::get('/get_directions', [CurrencyController::class,"Exchange"]);
Route::get('/calculate', [CurrencyController::class,"Calculate"]);
Route::post('/create_order', [OrdersController::class,"store"]);
