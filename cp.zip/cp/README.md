1. Скопіюйте та переменуйте файл "env.example" в ".env" та запишить туди свох дані
2. Спочатку налаштуємо среду для цього виконайте команди php composer.phar install,npm install,php artisan storage:link  
3. Тепер треа зібрати бандл js  для цього npm run build
4. Якщо ви ввели свої дані в .env треба зробити міграцію php artisan migrate --seed
5. Щоб запустити без сервера треба ввести команду php artisan serve